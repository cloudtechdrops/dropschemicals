<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class JobApplicationController extends Controller
{
    public function submit(Request $request)
    {
        // Validate the form data
        $request->validate([
            'full_name' => 'required|string|max:255',
            'email' => 'required|email',
            'position' => 'required|string|max:255',
            'employment_status' => 'required',
            'resume' => 'required|mimes:pdf,doc,docx|max:2048', // Accept PDF, DOC, DOCX files (max 2MB)
        ]);

        // Store the resume file
        $resumePath = $request->file('resume')->store('resumes', 'public');

        // Prepare email details
        $emailData = [
            'full_name' => $request->full_name,
            'email' => $request->email,
            'position' => $request->position,
            'employment_status' => $request->employment_status,
        ];

        Mail::send('emails.job_application', $emailData, function ($message) use ($request) {
            $message->to('info@dropschemicals.com') // Replace with the recipient's email
                    ->subject('New Job Application: ' . $request->position)
                    ->attach($request->file('resume')->getRealPath(), [
                        'as' => $request->file('resume')->getClientOriginalName(), // Use the original file name
                        'mime' => $request->file('resume')->getMimeType(),        // Set the correct MIME type
                    ]);
        });
        // Redirect back with a success message
        return back()->with('success', 'Your application has been submitted successfully!');
    }
}
