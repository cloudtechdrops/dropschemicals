<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\FeedbackMail;

class FeedbackController extends Controller
{
    public function submitFeedback(Request $request)
    {
        // Validate the form data
        $validated = $request->validate([
            'companyName' => 'required|string|max:255',
            'date' => 'required|date',
            'surveyBy' => 'required|string|max:255',
            'phone' => 'required|digits:10',
            'email' => 'required|email|max:255',
            'products' => 'nullable|string',
            'experience' => 'nullable|string',
            'price' => 'nullable|string',
            'quality' => 'nullable|string',
            'expectations' => 'nullable|string',
            'suggestions' => 'nullable|string',
        ]);

        // Send the email using the FeedbackMail mailable
        Mail::to('info@dropschemicals.com')->send(new FeedbackMail($validated));

        // Redirect back with a success message
        return back()->with('success1', 'Your feedback has been submitted successfully!');
    }
}

