<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactFormMail;

class ContactController extends Controller
{
    public function sendEmail(Request $request)
    {
        // Validate the form input
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone_number' => 'required|digits:10',
            'location' => 'required|string|max:255',
            'company' => 'required|string|max:255',
            'product' => 'required|string|max:255',
            'quantity' => 'required|string|max:255',
            'industry' => 'required|string|max:255',
            'message' => 'nullable|string|max:1000',
        ]);

        // Send the email using the ContactFormMail mailable
        Mail::to('info@dropschemicals.com')->send(new ContactFormMail($validated));

        // Redirect back with a success message
        return back()->with('success', 'Your message has been sent successfully!');
    }
}
?>
