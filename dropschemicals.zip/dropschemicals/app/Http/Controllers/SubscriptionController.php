<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class SubscriptionController extends Controller
{
    public function subscribe(Request $request)
{
    $request->validate([
        'email' => 'required|email',
    ]);

    try {
        // Send the thank-you email
        Mail::raw('Thank you for subscribing to our newsletter!', function ($message) use ($request) {
            $message->to($request->email)
                    ->subject('Subscription Confirmation');
        });

        return response()->json([
            'success' => true,
            'message' => 'Thank you for subscribing! A confirmation email has been sent.',
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to send the email. Please try again later.',
            'error' => $e->getMessage(), // Optional for debugging
        ], 500);
    }
}
}