<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\JobApplicationController;
use App\Http\Controllers\SubscriptionController;





/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('layouts.app');
// });


Route::get('/', function () {
    return view('drops.home');
})->name('/');

Route::get('ourservices', function () {
    return view('drops.ourservies');
})->name('ourservices');

Route::get('career', function () {
    return view('drops.career');
})->name('career');

Route::get('blog', function () {
    return view('drops.blog');
})->name('blog');

Route::get('about', function () {
    return view('drops.about');
})->name('about');

Route::get('contact', function () {
    return view('drops.contact');
})->name('contact');


// email sender

Route::post('contact/send', [ContactController::class, 'sendEmail'])->name('contact.sendEmail');



Route::post('contact/submit', [FeedbackController::class, 'submitFeedback'])->name('feedback.submit');

Route::post('/job/submit', [JobApplicationController::class, 'submit'])->name('job.submit');

// Route::post('/subscribe', [SubscriptionController::class, 'store'])->name('subscribe');
// Route::post('/subscribe', [SubscriptionController::class, 'subscribe'])->name('subscribe');

Route::post('/subscribe', [SubscriptionController::class, 'subscribe'])->name('subscribe');




