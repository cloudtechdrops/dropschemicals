

<?php $__env->startSection('content'); ?>

<!--=====HERO AREA START=======-->

  <div class="common-hero" style="background-image: url('<?php echo e(asset('/image/bg/bg\ \(4\).jpg')); ?>')"  id="aboutself">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="common-hero-heading">
            <h1 class="text-60 sm:text-30 md:text-30 leading-56 font-semibold white">About Us</h1>
            <div class="page-change">
              <ul>
                <li class="inline-block"><a href="<?php echo e(route('/')); ?>"
                    class="inline-block text-16 leading-16 white font-semibold">Home</a></li>
                <li class="inline-block arrow text-16 leading-16 white font-normal"><i
                    class="fa-solid fa-angle-right"></i></li>
                <li class="inline-block text-16 leading-16 white font-normal">About Us</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--=====HERO AREA END=======-->

  <!--=====ABOUT AREA START=======-->

  <div class="about-page-sec1 sp _relative" ID="CHEMICAL">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="heading3">
            <span class="span1 mb-16 inline-block text-18 leading-18 title1 font-normal mb-16"><img
                src="<?php echo e(asset('/img/New folder/icon/slide-icon.ico')); ?>" alt=""> Meet Drops Chemicals</span>
            <h2 class="text-44 sm:text-27 md:text-30 leading-56 pb-1 font-semibold title1">Innovative Chemical Manufacturing
              Solutions</h2>
          </div>
        </div>
      </div>
      <div class="row align-items-center -mt-140 md:mt-30 mt-1">
        <div class="col-lg col-md-6">
          <div class="image-area text-center">
            <div class="image image-anime _relative pt-5 " data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
              <img class="w-full " src="<?php echo e(asset('/img/about/about-page-sec1-img1.jpg')); ?>" alt="" >
            </div>
            <a href="#" class="bottom-text mt-20 inline-block text-20 leading-20 font-semibold title1">AGRICULTURE</a>
          </div>
        </div>

        <div class="col-lg-5 col-md-6">
          <div class="image-area ml-40 sm:mt-30 mr-40 text-center _relative">
            <div class="image image-anime _relative" data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
              <img class="w-full" src="<?php echo e(asset('/img/about/about-page-sec1-img2.png')); ?>" alt="">
            </div>

            <a href="#" class="bottom-text mt-20 inline-block text-20 leading-20 font-semibold title1">Formulation</a>


          </div>
        </div>

        <div class="col-lg col-md-12 md:mt-30 sm:mt-30">
          <div class="image-area">
            <p class="mb-30 text-16 font-normal pera1 leading-26">Committed to sustainability and innovation, Drops
              Chemicals leads the way in advancing agriculture and healthcare solutions. Partnering with farmers,
              agribusinesses, healthcare providers, and public institutions, we deliver transformative solutions that
              tackle today’s challenges and shape a better future.</p>

            <div class="text-center">
              <div class="image about3-image3 mr-40 mt-30 image-anime _relative" data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
                <img class="w-full" src="<?php echo e(asset('/img/about/about-page-sec1-img3.jpg')); ?>" alt="">
              </div>
              <a href="#"
                class="bottom-text mr-25 mt-20 inline-block text-20 leading-20 font-semibold title1">Distributor</a>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!--=====ABOUT AREA END=======-->

  <!--=====SERVICE AREA START=======-->

  <div class="about-service bg1 sp _relative" style="background:var(--primary-gradient)">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="heading4">
            <span class="span1 mb-16 inline-block text-22 leading-18 title1 font-normal mb-16 white"  ><img
                src="<?php echo e(asset('/img/New folder/icon/slide-icon.ico')); ?>" alt=""> Our Service</span>


            <p class=" text-25 sm:text-20 md:text-20 leading-56 font-semibold title1">We specialize in providing
              high-quality chemicals across various
              industries we offer a diverse range of products to ensure the
              customer satisfaction we are specialized in
            </p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="about-service-buttons">
            <button class="service4-prev-arrow"><i class="fa-solid fa-angle-left"></i></button>
            <button class="service4-next-arrow"><i class="fa-solid fa-angle-right"></i></button>
          </div>
        </div>
      </div>

      <div class="border4"></div>
      <div class="row">
        <div class="col-lg-12">
          <div class="service4-slider-all mt-40  p-2" >
            <div class="about-service-single-slider">
              <div class="icon">
                <img src="<?php echo e(asset('/img/icons/service4-icon1.svg')); ?>" alt="">
              </div>
              <div class="heading4 mt-20  heading4R">
                <h4><a class="text-20 leading-20 font-semibold inline-block title1" href="<?php echo e(route('ourservices')); ?> ">AGRO
                    & AQUACULTURE INDUSTRIES</a></h4>
                <p class="mt-16 text-14 font-normal pb-15 pera1 leading-26">We supply high-quality agrochemicals used in
                  agriculture to improve crop
                  yields and protect plants from pests and diseases.
                </p>

              </div>
            </div>

            <div class="about-service-single-slider">
              <div class="icon">
                <img src="<?php echo e(asset('/img/icons/service4-icon2.svg')); ?>" alt="">
              </div>
              <div class="heading4 mt-20 heading4R ">
                <h4><a class="text-20 leading-20 font-semibold inline-block title1 " href="<?php echo e(route('ourservices')); ?> ">FOOD
                    PROCESSING CHEMICALS</a></h4>
                <p class="mt-16 text-14 font-normal pb-20 pera1 leading-26"> We supply food processing chemicals,
                  including food colors, acetic acid, calcium chloride based on
                  client specification
                </p>

              </div>
            </div>

            <div class="about-service-single-slider">
              <div class="icon">
                <img src="<?php echo e(asset('/img/icons/service4-icon3.svg')); ?>" alt="">
              </div>
              <div class="heading4 mt-20 heading4R ">
                <h4><a class="text-20 leading-20 font-semibold inline-block title1"
                    href="<?php echo e(route('ourservices')); ?> ">INDUSTRIAL CHEMICALS</a></h4>
                <p class="mt-16 text-14 font-normal pb-20 pera1 leading-26">Basic industrial chemicals include products
                  such as sulfuric acid,
                  hydrochloric acid, sodium hydroxide, and nitric acid, among others.


                </p>

              </div>
            </div>

            <div class="about-service-single-slider">
              <div class="icon">
                <img src="<?php echo e(asset('/img/icons/service4-icon1.svg')); ?>" alt="">
              </div>
              <div class="heading4 mt-20 heading4R ">
                <h4><a class="text-20 leading-20 font-semibold inline-block title1" href="<?php echo e(route('ourservices')); ?> ">WATER
                    TREATMENT CHEMICALS</a></h4>
                <p class="mt-16 text-14 font-normal pb-17 pera1 leading-26">We provide water treatment chemicals like
                  chlorine, alum, and polyelectrolyte for oil, gas, mining, and municipal industrie</p>

              </div>
            </div>

            <div class="about-service-single-slider">
              <div class="icon">
                <img src="<?php echo e(asset('/img/icons/service4-icon2.svg')); ?>" alt="">
              </div>
              <div class="heading4 mt-20 heading4R">
                <h4><a class="text-20 leading-20 font-semibold inline-block title1"
                    href="<?php echo e(route('ourservices')); ?> ">HYGIENE PRODUCTS</a></h4>
                <p class="mt-16 text-14 font-normal pb-20 pera1 leading-26">We offer hand sanitizers and cleaning
                  agents, essential for maintaining hygiene in hospitality and food industries</p>

              </div>
            </div>

            <div class="about-service-single-slider">
              <div class="icon">
                <img src="<?php echo e(asset('/img/icons/service4-icon3.svg')); ?>" alt="">
              </div>
              <div class="heading4 mt-20 heading4R">
                <h4><a class="text-20 leading-20 font-semibold inline-block title1"
                    href="<?php echo e(route('ourservices')); ?> ">DETERGENT AND SOAP</a></h4>
                <p class="mt-16 text-14 font-normal pb-20 pera1 leading-26">We provide AOS liquid, isopropyl alcohol,
                  and high-quality raw materials for soap and detergent manufacturing</p>

              </div>
            </div>

          </div>
        </div>
      </div>

    </div>

  </div>

  <!--=====SERVICE AREA END=======-->

  <!--=====ABOUT AREA START=======-->

  <div class="about1 sp">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="about1-images">
            <div class="image1 absolute image-anime reveal top-0 left-0  " style=" border-radius:50%;box-shadow:5px 5px 20px rgba(46, 46, 241, 0.9);">
              <img src="<?php echo e(asset('/img/about/about1-image1.png')); ?>" alt=""  style="width:250px;height:250px">
            </div>
            <div class="image2 absolute top-90 right-0  image-anime reveal " style=" background-color:transparent;top:25% ;">
              <img src="<?php echo e(asset('/img/about/about2-image.png')); ?>" alt=""  style="width:250px;height:250px">
            </div>
            <div class="image3 absolute left-0 image-anime reveal " style="top:50% ;border-radius:50%;box-shadow:5px 5px 20px rgba(46, 46, 241, 0.9);">
              <img src="<?php echo e(asset('/img/about/about1-image3.png')); ?>" alt="" style="width:250px ;height:250px ;" >
            </div>
            <div class="shape absolute top-0 animate2 -z-1">
              <img src="<?php echo e(asset('/img/shapes/about1-shape.png')); ?>" alt="">
            </div>
          </div>
        </div>

        <div class="col-lg-6">
          <div class="heading1 pl-50 md:pl-0 xs:pl-0 md:pt-30 sm:pt-30">
            <span class="span1 text-18 leading-18 title1 font-normal mb-16"><img src="<?php echo e(asset('/img/New folder/icon/slide-icon.ico')); ?>"
                alt=""> Our Mission & Vision</span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1">Empowering Innovation and Growth</h2>
            <p class="mt-16 text-16 font-normal pera1 leading-26">Develop & deliver innovative chemical products meeting
              customer needs & minimizing environmental impact.
              To empower our customers with sustainable chemical
              solutions that enhance their productivity and
              competitiveness </p>
            <p class="mt-16 text-16 font-normal pera1 leading-26"> To lead in sustainable chemicals, fostering
              innovation for planet
              impact.
              Trusted provider of high-quality specialty chemicals, exceeding
              customer expectations through excellence and reliability.</p>

            <div class="button mt-30">
              <a href="<?php echo e(route('ourservices')); ?>" class="theme-btn15 inline-block white text-16 leading-16 font-semibold " >Service Us</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--=====ABOUT AREA END=======-->

  <!--=====OUR VALUES AREA START=======-->

  <div class="our-values sp bg1" style="background:var(--primary-gradient)">
    <div class="container" style="background:var(--primary-gradient)">
      <div class="row">
        <div class="col-lg-6">
          <div class="heading1 pl-50 md:pl-0 xs:pl-0 md:pt-30 sm:pt-30">
            <span class="span1 text-22 leading-18 title1 font-normal mb-16 white"><img
                src="<?php echo e(asset('/img/New folder/icon/slide-icon.ico')); ?>" alt=""> Our Values</span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold white title1">We work is conducted honest
              transparency.</h2>
            <div class="our-values-box">
              <div class="icon">
                <span><i class="fa-solid fa-check"></i></span>
              </div>
              <div class="heading1">
                <h4><a href="#" class="text-18 leading-18 font-semibold title1">BEST COMPANY</a></h4>
                <p class="mt-10 text-16 font-normal  mt-14 leading-26 ">we do not compromise quality of
                  chemicals and we try to fulfill the customer
                  requirements we strive to exceed their
                  expectations at every step</p>
              </div>
            </div>

            <div class="our-values-box">
              <div class="icon">
                <span><i class="fa-solid fa-check"></i></span>
              </div>
              <div class="heading1">
                <h4><a href="#" class="text-18 leading-18 font-semibold title1">GOOD SERVICE</a></h4>
                <p class="mt-10 text-16 font-normal  mt-14 leading-26">we take great pride in the quality of our
                  products and services. We believe in
                  delivering customized solutions that meet
                  the specific needs of our customer
                  enquiries</p>
              </div>
            </div>

            <div class="our-values-box">
              <div class="icon">
                <span><i class="fa-solid fa-check"></i></span>
              </div>
              <div class="heading1">
                <h4><a href="#" class="text-18 leading-18 font-semibold title1">REPUTATION</a></h4>
                <p class="mt-10 text-16 font-normal  mt-14 leading-26">As a result, we have earned a reputation
                  for being one of the most trusted and
                  reliable suppliers in the region</p>
              </div>
            </div>

            <div class="our-values-box">
              <div class="icon">
                <span><i class="fa-solid fa-check"></i></span>
              </div>
              <div class="heading1">
                <h4><a href="#" class="text-18 leading-18 font-semibold title1">BEST MANAGEMENT</a></h4>
                <p class="mt-10 text-16 font-normal  mt-14 leading-26">we proudly have the best team for
                  coordinating each other supporting each
                  others we proudly say we have the best
                  management and best team</p>
              </div>
            </div>

            <div class="button mt-30">
              <a href="<?php echo e(route('ourservices')); ?> "
                class="theme-btn15 inline-block white text-16 leading-16 font-semibold ">Service Us</a>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="row">
            <div class="col-md-6">
              <div class="image image-anime _relative" data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
                <img class="w-full" src="<?php echo e(asset('/img/about/values-img1.png')); ?>" alt="">
              </div>
            </div>

            <div class="col-md-6">
              <div class="image sm:mt-20 image-anime _relative" data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
                <img class="w-full" src="<?php echo e(asset('/img/about/values-img2.png')); ?>" alt="">
              </div>
            </div>

            <div class="col-md-12">
              <div class="image mt-30 image-anime _relative" data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
                <img class="w-full" src="<?php echo e(asset('/img/about/values-img3.png')); ?>" alt="">
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

  <!--=====OUR VALUES AREA END=======-->

  <!--=====PROCESS AREA START=======-->

  <div class="process sp _relative" style="background-color: #F1F5FD;">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 m-auto text-center">
          <div class="heading1">
            <span class="span1 text-18 leading-18 title1 font-normal mb-16"><img
                src="<?php echo e(asset('/img/New folder/icon/slide-icon.ico')); ?>" alt=""> Our Process</span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1">How Drops Chemicals Works</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 d-none d-lg-block">
          <div class="video-area1 _relative" style="background-image: url('<?php echo e(asset('/img/bg/video-area1-bg.jpg')); ?>');">

            <div id="play-btn" class="video-button play-btn" href="https://www.youtube.com/watch?v=Y8Xp">
              <a class="video-play-button">
                <span></span>
              </a>
            </div>

          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="300">
          <div class="process-bottom-box text-center">
            <div class="icon">
              <img src="<?php echo e(asset('/img/icons/solution-bottom-icon1.svg')); ?>" alt="">
            </div>
            <div class="heading1">
              <h4><a href="#" class="text-20 leading-20 font-semibold title1 inline-block mt-24">Initial Consultation
                </a></h4>
              <p class="mt-16 mt-16 text-16 font-normal pera1 leading-26">We begin with an in-depth consultation to
                understand your specific needs and objectives.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="300">
          <div class="process-bottom-box text-center">
            <div class="icon">
              <img src="<?php echo e(asset('/img/icons/solution-bottom-icon2.svg')); ?>" alt="">
            </div>
            <div class="heading1">
              <h4><a href="#" class="text-20 leading-20 font-semibold title1 inline-block mt-24">Customized Testing Plan
                </a></h4>
              <p class="mt-16 mt-16 text-16 font-normal pera1 leading-26">Based on your requirements, we develop a
                customized testing plan tailored to your materials.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="300">
          <div class="process-bottom-box text-center">
            <div class="icon">
              <img src="<?php echo e(asset('/img/icons/solution-bottom-icon3.svg')); ?>" alt="">
            </div>
            <div class="heading1">
              <h4><a href="#" class="text-20 leading-20 font-semibold title1 inline-block mt-24">Consultation & Support
                </a></h4>
              <p class="mt-16 mt-16 text-16 font-normal pera1 leading-26">e offer follow-up consultations to review the
                results and discuss any <br> further steps.</p>
            </div>
          </div>
        </div>

      </div>

    </div>
  </div>

  <!--=====PROCESS AREA END=======-->

  <!--=====TESTIMONIAL AREA START=======-->

  <div class="tes2 sp" id="tes" style="background-color:#44c9f4;">
    <div class="container">

      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="heading2-w" >
            <span class="span1 mb-16 inline-block text-18 leading-18 white font-normal mb-16  " style="float: inherit;"><img
                src="<?php echo e(asset('/img/New folder/icon/slide-icon.ico')); ?>" alt=""   style="max-width: 50px; filter: brightness(1.5) contrast(1.2);">Testimonials</span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold white">Success Stories and Experiences
              with Drops Chemicals</h2>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="text-end sm:text-start md:text-start sm:mt-20 md:mt-20">
            <a href="#CHEMICAL" class="theme-btn16 inline-block white text-16 leading-16 font-semibold ">About us</a>
          </div>
        </div>
      </div>

      <div class="space60"></div>
      <div class="row">
        <div class="col-lg-12 _relative">
          <div class="tes2-slider">
            <div class="tes2-single-slider">
              <div class="row align-items-center">
                <div class="col-lg-6">
                  <div class="heading2-w mx-2">
                    <h3 class="text-32 leading-32 font-semibold black mb-2">Exceptional  Quality and Service  </h3>
                    <p class="text-22 font-normal pera2 leading-32 mt-8 pb-2 text-white">""Drops Chemicals delivers exceptional precision and accuracy, revolutionizing product innovation with reliable chemical analysis. Their expertise drives informed decisions, reshaping the global chemical industry."</p>
               
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="tes2-images">
                    <div class="image">
                      <img src="<?php echo e(asset('/img/testimonial/WhatsApp Image 2024-11-27 at 11.35.26 AM-fotor-bg-remover-2024112718022.png')); ?>" alt="">
                    </div>
                    <div class="shape">
                      <img src="<?php echo e(asset('/img/shapes/tes2-shape.png')); ?>" alt="">
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="tes2-single-slider">
              <div class="row align-items-center">
                <div class="col-lg-6 ">
                  <div class="heading2-w mx-2">
                    <h3 class="text-32 leading-32 font-semibold  mb-2">Exceptional Service and Precision</h3>
                    <p class="text-22 font-normal pera2 leading-32 mt-8 text-white">"The precision and reliability that Drops Chemicals offers are truly remarkable. Their services as a manufacturer and supplier have been crucial to our product innovation, providing dependable solutions for well-informed decision-making. We are thoroughly impressed with the expertise and support they've delivered. This manufacturer and supplier is transforming the industry."</p>
                    
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="tes2-images">
                    <div class="image">
                      <img src="<?php echo e(asset('/img/testimonial/WhatsApp Image 2024-11-27 at 11.35.26 AM-fotor-bg-remover-2024112718022.png')); ?>" alt="">
                    </div>
                    <div class="shape">
                      <img src="<?php echo e(asset('/img/shapes/tes2-shape.png')); ?>" alt="">
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

          <div class="tes2-buttons">
            <button class="tes2-prev-arrow"><i class="fa-solid fa-angle-left"></i></button>
            <button class="tes2-next-arrow"><i class="fa-solid fa-angle-right"></i></button>
          </div>

        </div>
      </div>

    </div>
  </div>

  <!--=====TESTIMONIAL AREA END=======-->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>


<style>

:root {
  --font1: Poppins;
}
h1,h2,h3,a,span{
  font-family: var(--font1);
}
a{
  font-size: 18px !important;
}

 /* font color changing */
 .font-color-footer {
            color: rgb(91, 185, 223);

        }

.z-index-1 {
  position: relative;  /* Needed to apply z-index */
  z-index: 1;
}
    .span1{
      font-weight: bold;
      

    }
    .heading4R{
      height:15rem ;
      overflow:auto;
      padding-bottom: 3em;
    }

    .image {
    display: inline-block;
    position: relative;
    width: auto;
    height: auto;
    padding: 15px;
    background-color: #fff;
    border-radius: 10px; 
    box-shadow: 0 4px 12px rgba(7, 160, 180, 0.5); 
    transition: box-shadow 0.3s ease-in-out;
}

.image img {
    display: block;
    max-width: 100%;
    height: auto;
    border-radius: 8px; /* Optional: round corners of the image */
}

.image:hover {
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15),0 8px 20px rgba(0, 0, 0, 0.15),0 8px 20px rgba(0, 0, 0, 0.15);
     /* Darker shadow on hover for effect */
}

  
  </style>

   
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dropchemical\dropschemicals\resources\views/drops/about.blade.php ENDPATH**/ ?>