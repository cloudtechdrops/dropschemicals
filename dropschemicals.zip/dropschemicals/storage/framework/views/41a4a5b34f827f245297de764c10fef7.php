<h3>Feedback from <?php echo e($feedbackData['companyName']); ?></h3>
<p><strong>Date:</strong> <?php echo e($feedbackData['date']); ?></p>
<p><strong>Survey Completed by:</strong> <?php echo e($feedbackData['surveyBy']); ?></p>
<p><strong>Phone:</strong> <?php echo e($feedbackData['phone']); ?></p>
<p><strong>Email:</strong> <?php echo e($feedbackData['email']); ?></p>

<h4>Feedback Responses:</h4>
<p><strong>1. What products, and or services did you purchase?</strong> <?php echo e($feedbackData['products']); ?></p>
<p><strong>2. Was the purchasing experience positive?:</strong> <?php echo e($feedbackData['experience']); ?></p>

<p><strong>3. Supplier Performance:</strong></p>
<p><strong>Price:</strong> <?php echo e($feedbackData['price']); ?></p>
<p><strong>Quality:</strong> <?php echo e($feedbackData['quality']); ?></p>

<p><strong>4. Did the products meet expectations?:</strong> <?php echo e($feedbackData['expectations']); ?></p>
<p><strong>5. Suggestions to improve service:</strong> <?php echo e($feedbackData['suggestions']); ?></p>
<?php /**PATH D:\dropchemical\dropschemicals\resources\views/emails/feedback.blade.php ENDPATH**/ ?>