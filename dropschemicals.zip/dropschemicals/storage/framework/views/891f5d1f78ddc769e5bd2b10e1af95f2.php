

<?php $__env->startSection('content'); ?>

 <!--=====HERO AREA START=======-->

 <div class="common-hero" style="background-image: url('<?php echo e(asset('/image/bg/bg\ \(2\).jpg')); ?>');" id="blogself" style="overflow-x:hidden">
    <div class="container">
      <div class="row">
        <div class="col-lg-10">
          <div class="common-hero-heading">
            <h1 class="text-60 sm:text-30 md:text-30 leading-56 font-semibold white">Blog</h1>
            <div class="page-change">
              <ul>
                <li class="inline-block"><a href="<?php echo e(route('/')); ?>"
                    class="inline-block text-16 leading-16 white font-semibold">Home</a></li>
                <li class="inline-block arrow text-16 leading-16 white font-normal"><i
                    class="fa-solid fa-angle-right"></i></li>
                <li class="inline-block text-16 leading-16 white font-normal">Blog </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--=====HERO AREA END=======-->

  <!--=====RESEARCH DETAILS AREA START=======-->

  <div class="research-details  _relative">
    <div class="container-fluid" style="margin:3px 0 ;">


      <div class="row "  >

        <div class="col-lg-7">
          <div class="reseach-details-content mr-30 sm:mr-0 md:mr-0 md:mt-30 sm:mt-30">
            <article>
              <div class="research-content-single" style="width:90%">
                <div class="row">
                <div class="image _relative image-anime">
                  <img class="w-full" src="<?php echo e(asset('/img/blog/blog-details-img1.jpg')); ?>" alt="">
                </div>
              
              
                <div class="heading1">
                  
                  <p class="mt-20 text-16 font-normal pera1 leading-26">Ease of Use: We prioritize user-friendly packaging that simplifies handling, storage, and usage. Whether it's easy-to-open seals or clear labeling, we ensure that our packaging adds value to your experience.

                  </p>
                </div>
                </div>
                <div class="heading1">
                  
                  <p class="mt-20 text-16 font-normal pera1 leading-26" style="background:  linear-gradient(108.3deg, rgb(196, 214, 252) 1%, rgba(187, 187, 187, 0) 70.9%);">Sustainability: We are committed to reducing our environmental footprint. Our packaging materials are recyclable, eco-friendly, and designed to minimize waste.

                  </p>
                </div>
              </div>
            </article>

            <article>
              <div class="research-content-single">
                <div class="heading1">
                 
                  <p class="mt-20 text-16 font-normal pera1 leading-26" style="width:100%;padding-right: 5px; 
                    
                  text-overflow: ellipsis;">Product Integrity: High-quality packaging preserves the effectiveness and stability of our products. Our packaging solutions are designed to protect against contamination, temperature fluctuations, and exposure to external elements.</p>
                </div>

                <div class="heading1"style="padding-right: 5px;" >
                  <h3 class="text-32 leading-32 font-semibold title1 mt-30"> Packaging Solutions</h3>
                  <p class="mt-20 text-16 font-normal pera1 leading-26" style="background:  linear-gradient(108.3deg, rgb(196, 214, 252) 1%, rgba(187, 187, 187, 0) 70.9%);"><b> Tamper-proof </b>seals to ensure product authenticity <br>
                   <b>  Leak-proof containers </b>to avoid spills and maintain safety<br>
                    <b> Recyclable and eco-friendly materials</b> to reduce environmental impact<br>
                   <b> Clear labeling </b>for easy identification and &nbsp;usage instructions</p>
                  
                </div>
                <div class="heading1">
                  <h3 class="text-25 leading-32 font-semibold title1 mt-30" >Delivering Excellence: A Customer-Centric Approach to Chemical Manufacturing & Supply
                  </h3>
                  <p class="mt-20 text-16 font-normal pera1 leading-26">At Drop Chemicals, our customers are at the heart of everything we do. As a trusted leader in chemical manufacturing and supply, we are committed to providing high-quality products tailored to meet the unique needs of diverse industries. From agrochemicals to water treatment solutions, we prioritize efficiency, innovation, and customer satisfaction.

                  </p>
                </div>
              </div>

            </article>

            <article>
              <div class="reseach-details-content mt-16">
                <div class="row align-items-center">
                  <div class="col-lg-5">
                    <div class="image image-anime mt-30 _relative">
                      <img class="w-full" src="<?php echo e(asset('/img/blog/blog-details-img2.jpg')); ?>" alt="">
                    </div>
                  </div>
                  <div class="col-lg-7">
                    <div class="heading1">
                      <p class="mt-20 text-16 font-normal pera1 leading-26" style="background:  linear-gradient(108.3deg, rgb(196, 214, 252) 1%, rgba(187, 187, 187, 0) 70.9%);"><b>Custom-Tailored Solutions</b>
                        Every business is unique, and so are its chemical requirements. We work closely with our customers to understand their specific needs and provide customized products and services that enhance productivity and performance.</p>
                      <p class="mt-20 text-16 font-normal pera1 leading-26" ><b> Unmatched Quality</b>
                        Quality is the cornerstone of our operations. Each product undergoes rigorous testing and quality assurance to ensure it meets industry standards and delivers consistent results.
                        
                        </p>
                    </div>
                  </div>
                </div>
                <div class="heading1">
                  <p class="mt-24 text-16 font-normal pera1 leading-26" style="background:  linear-gradient(108.3deg, rgb(196, 214, 252) 1%, rgba(187, 187, 187, 0) 70.9%);"><b> Reliable Supply Chain</b>
                    We understand the importance of timely delivery. With a streamlined supply chain and fast logistics network, we ensure your orders are delivered on time, every time, so you never experience downtime in your operations.</p>
                  <p class="mt-20 text-16 font-normal pera1 leading-26"><b> Eco-Friendly Practices</b>
                    Sustainability matters to us. We strive to develop chemical solutions that minimize environmental impact, helping our customers adopt greener practices while achieving their goals.
                    
                    </p>
                  
                </div>
              </div>
            </article>



            <div class="blog2-divider"></div>



            <div class="details-comment-area mt-40">
              <h3 class="text-32 text-32 font-semibold pb-10 title1 leading-24"></h3>
              <!-- Right Content Section -->
              <div class="col-md-12 right-container" style="padding:0 15px ;">
                <!-- Card 1 -->
                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="<?php echo e(asset('/img/New folder/img/about 1.png')); ?>" class="img-fluid rounded-start" alt="Image 1">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title">Basic Industrial Chemicals</h5>
                        <p class="card-text">Our range of basic industrial chemicals includes products such as sulfuric acid, hydrochloric acid, sodium hydroxide, and nitric acid, among others. These chemicals are widely used in industries such as textile, leather, paper,
                          and detergent manufacturing, among others.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Card 2 -->
                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="<?php echo e(asset('/img/New folder/img/about 2.png')); ?>" class="img-fluid rounded-start" alt="Image 2">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title">Food Chemicals</h5>
                        <p class="card-text">Our range of food chemicals includes preservatives, emulsifiers, and stabi- lizers, among others. These chemicals are used in the food industry to en- hance the taste, texture, and shelf life of food products.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Card 3 -->
                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="<?php echo e(asset('/img/New folder/img/about 3.png')); ?>" class="img-fluid rounded-start" alt="Image 3">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title">Water Treatment Chemicals</h5>
                        <p class="card-text">We offer a comprehensive range of water treatment chemicals, including chlorine, alum, and polyacrylamide. These chemicals are used to treat water in industries such as oil and gas, mining, and municipal water treat- ment.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Additional Cards -->
                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="<?php echo e(asset('/img/New folder/img/about 4.png')); ?>" class="img-fluid rounded-start" alt="Image 4">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title">Agro Chemicals</h5>
                        <p class="card-text">Drops Chemicals supplies high-quality agrochemicals that are used in agri- culture to improve crop yields and protect plants from pests and diseases. Our range of agrochemicals includes herbicides, insecticides, and fungi- cides, among others..</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="<?php echo e(asset('/img/New folder/img/about 5.png')); ?>" class="img-fluid rounded-start" alt="Image 5">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title">Acids & Solvents</h5>
                        <p class="card-text">Our range of acids and solvents includes products such as acetic acid, ace- tone, toluene, xylene among others. These chemicals are used in various industries such as paint, agro, industrial chemical formulation, etc</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="<?php echo e(asset('/img/New folder/img/about 6.png')); ?>" class="img-fluid rounded-start" alt="Image 6">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title">Hygiene Products</h5>
                        <p class="card-text">We offer a range of hygiene products, such as hand sanitizers, disinfec- tants, and cleaning agents, among others. These products are essential in maintaining a clean and hygienic environment in industries such as health- care, hospitality, and food processing.
                          </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="card mb-3">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="<?php echo e(asset('/img/New folder/img/about 7.png')); ?>" class="img-fluid rounded-start" alt="Image 7">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title">Stripping Process.</h5>
                        <p class="card-text">Drops Chemicals offers a wide range of stripping services that are used to remove paint, varnish, and other coatings from metal surfaces. Our strip- ping process is highly effective and safe to use, and they have been widely appreciated by our customers.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>


            </div>


          </div>
        </div>

        <div class="col-lg-5">
          <div class="sidebar-area-all">

            <div class="details-sidebar bg1 p-24-20">
              <h3 class="text-24 leading-24 font-semibold title1">Categories</h3>
              <div class="caregory-itmes pt-10">
                <ul>
                <li><a href="<?php echo e(route('ourservices', ['open' => 'acid'])); ?>">Agro & Aquaculture</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'hygiene'])); ?>">Detergent and Soap</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'food'])); ?>">Food</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'hygiene1'])); ?>">Hygiene</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'metal'])); ?>">Metal Finishing</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'petrol'])); ?>">Petro</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'poultry'])); ?>">Poultry</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'solvents'])); ?>">Solvents</a></li>
        <li><a href="<?php echo e(route('ourservices', ['open' => 'water'])); ?>">Water Treatment</a></li>
                </ul>
              </div>
            </div>

            <div class="details-sidebar bg1 p-24-20 mt-32">
              <h3 class="text-24 leading-24 font-semibold title1">You Still Have A Question</h3>
              <p class="mt-16 text-16 font-normal pera1 leading-26">If you cannot find answer to your question our FAQ,
                you can always contact us. Web will answer you shortly!</p>
              <div class="buttons pt-10">
                <a href="<?php echo e(route('ourservices')); ?>"
                  class="theme-btn18 mt-16 inline-block white text-16 leading-16 font-semibold "><img
                    src="<?php echo e(asset('/img/icons/details-sidebar-contact1.svg')); ?>" alt="">Services</a>
                <a href="<?php echo e(route('contact')); ?>"
                  class="theme-btn19 mt-16 inline-block white text-16 leading-16 font-semibold "><img
                    src="<?php echo e(asset('/img/icons/details-sidebar-contact2.svg')); ?>" alt="">Contact</a>
              </div>
            </div>


          </div>
        </div>
      </div>
      </div>

      <!--=====RESEARCH DETAILS AREA START=======-->

      <!--=====BLOG DETAILS BOXS START=======-->

      <div class="pb-100">
        <div class="container">
          <div class="row" >
            <div class="col-lg-6  text-center">
              <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1">More Blogs</h2>
            </div>
          </div>

          <div class="row mt-30" style="padding:0 15px ;">
            <div class="col-lg-4 col-md-6">
              <div class="blog-page-box mt-30">
                <div class="image image-anime overflow-hidden _relative">
                  <img src="<?php echo e(asset('/img/blog/blog-page-box2.jpg')); ?>" alt="">
                </div>
                <div class="heading1">
                  <a href="#" class="tag text-16 leading-16 inline-block font-normal title1">Packaging </a>
                  <h4><a href="#"
                      class="text-20 leading-28 mt-16 inline-block title1 font-semibold">We ensure safe, secure, eco-friendly packaging protection.</a></h4>
                 
                 
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="blog-page-box mt-30">
                <div class="image image-anime overflow-hidden _relative">
                  <img src="<?php echo e(asset('/img/blog/blog-page-box1.jpg')); ?>" alt="">
                </div>
                <div class="heading1">
                  <a href="#" class="tag text-16 leading-16 inline-block font-normal title1">Delivery</a>
                  <h4><a href="#"
                      class="text-20 leading-28 mt-16 inline-block title1 font-semibold">Fast, reliable, on-time, efficient, secure, and seamless delivery.</a></h4>
                 
                  
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="blog-page-box mt-30">
                <div class="image image-anime overflow-hidden _relative">
                  <img src="<?php echo e(asset('/img/blog/blog-page-box3.jpg')); ?>" alt="">
                </div>
                <div class="heading1">
                  <a href="#" class="tag text-16 leading-16 inline-block font-normal title1">Customer-Centric Service </a>
                  <h4><a href="#" class="text-20 leading-28 mt-16 inline-block title1 font-semibold">Your satisfaction is our priority, delivering  consistently.</a></h4>
                  
                  
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      <!--=====BLOG DETAILS BOXS END=======-->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>

:root {
  --font1: Poppins;
}
h1,h2,h3,a,span{
  font-family: var(--font1);
}
a{
  font-size: 18px !important;
}

 /* font color changing */
 .font-color-footer {
            color: rgb(91, 185, 223);

        }


    .right-content {
    width: 60%; /* Adjust width as needed */
    padding: 0 20px; /* Add some spacing */
    overflow-y: auto; /* Enable scrolling if content overflows */
}
.card{
    transition: all 1s;
}
.card:hover{
    background-color: rgb(17, 15, 189);
    color: #fff;

}
.boxsize{
  box-sizing: content-box;
}
@media screen and (max-width: 500px) {

}
.heading1>p{
  width:100%;
  
}




  </style>

   
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dropchemical\dropschemicals\resources\views/drops/blog.blade.php ENDPATH**/ ?>