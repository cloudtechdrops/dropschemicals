<p><strong>Full Name:</strong> <?php echo e($full_name); ?></p>
<p><strong>Email:</strong> <?php echo e($email); ?></p>
<p><strong>Position:</strong> <?php echo e($position); ?></p>
<p><strong>Employment Status:</strong> <?php echo e($employment_status); ?></p>
<?php /**PATH D:\dropchemical\dropschemicals\resources\views/emails/job_application.blade.php ENDPATH**/ ?>