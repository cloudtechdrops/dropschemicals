

<?php $__env->startSection('content'); ?>



 <!--=====HERO AREA START=======-->

 <div class="common-hero" id="blogself">
  <div class="container">
      <div class="row">
          <div class="col-lg-10">
              <div class="common-hero-heading">
                  <h1 class="text-60 sm:text-30 md:text-30 leading-56 font-semibold white">Career</h1>
                  <div class="page-change">
                      <ul>
                          <li class="inline-block"><a href="<?php echo e(route('/')); ?>" class="inline-block text-16 leading-16 white font-semibold">Home</a></li>
                          <li class="inline-block arrow text-16 leading-16 white font-normal"><i class="fa-solid fa-angle-right"></i></li>
                          <li class="inline-block text-16 leading-16 white font-normal">career Details </li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>


<!-- Main Content -->
<div class="main-container my-3">
  <div class="row mx-3 ">
    <div class="card2">
      <h2 class="card__title">Join the Drops Chemicals Family!</h2>
      <p class="card__apply">
        Are you looking for a rewarding career in the chemical industry? We’re hiring talented professionals to join our team. From engineering to quality assurance, we offer roles where you can grow and make a difference. Discover opportunities with us today!
      </p>
    </div>
  </div>

  <div class="row cards m-2 col-lg-12">
    <span></span>

     <!--*********** card************ -->
    
    <div class="cardR card-1 col-lg-5" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300">
      <span class="span3"></span>
      <span class="span2"></span>
      
      <span class="span1"></span>

  <header class="card-header">
    <h3 class="job-title">Tele Calling Executive</h3>
    <p class="job-code">PPC/TCE/1181208</p>
    <p class="job-location">SalesSS - Erode</p>
  </header>

  <h2 class="card__title">1-2 years of experience required.</h2>
  <p class="job-dates">Posted On: 29 Oct 2024 | End Date: 05 Dec 2024</p>
  
  <p class="card__apply">
    <i class="fas fa-briefcase rotating-icon"></i>
    <a class="card__link"  class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">Apply Now <i class="fas fa-arrow-right"></i></a>
  </p>
    </div>
    <!--*********** card************ -->
    <div class="cardR card-1 col-lg-5" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300">
      <span class="span3"></span>
      <span class="span2"></span>
      
      <span class="span1"></span>

  <header class="card-header">
    <h3 class="job-title">Tele Calling Executive</h3>
    <p class="job-code">PPC/TCE/1181208</p>
    <p class="job-location">SalesSS - Erode</p>
  </header>

  <h2 class="card__title">1-2 years of experience required.</h2>
  <p class="job-dates">Posted On: 29 Oct 2024 | End Date: 05 Dec 2024</p>
  
  <p class="card__apply">
    <i class="fas fa-briefcase rotating-icon"></i>
    <a class="card__link"  class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">Apply Now <i class="fas fa-arrow-right"></i></a>
  </p>
    </div>
  <!--*********** card************ -->
    
    <div class="cardR card-1 col-lg-5" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300">
      <span class="span3"></span>
      <span class="span2"></span>
      
      <span class="span1"></span>

  <header class="card-header">
    <h3 class="job-title">Tele Calling Executive</h3>
    <p class="job-code">PPC/TCE/1181208</p>
    <p class="job-location">SalesSS - Erode</p>
  </header>

  <h2 class="card__title">1-2 years of experience required.</h2>
  <p class="job-dates">Posted On: 29 Oct 2024 | End Date: 05 Dec 2024</p>
  
  <p class="card__apply">
    <i class="fas fa-briefcase rotating-icon"></i>
    <a class="card__link"  class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">Apply Now <i class="fas fa-arrow-right"></i></a>
  </p>
    </div>
  <!--*********** card************ -->
    <div class="cardR card-1 col-lg-5" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300">
      <span class="span3"></span>
      <span class="span2"></span>
      
      <span class="span1"></span>

  <header class="card-header">
    <h3 class="job-title">Tele Calling Executive</h3>
    <p class="job-code">PPC/TCE/1181208</p>
    <p class="job-location">SalesSS - Erode</p>
  </header>

  <h2 class="card__title">1-2 years of experience required.</h2>
  <p class="job-dates">Posted On: 29 Oct 2024 | End Date: 05 Dec 2024</p>
  
  <p class="card__apply">
    <i class="fas fa-briefcase rotating-icon"></i>
    <a class="card__link"  class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">Apply Now <i class="fas fa-arrow-right"></i></a>
  </p>
    </div>
  <!--*********** card************ -->
    <div class="cardR card-1 col-lg-5" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300">
      <span class="span3"></span>
      <span class="span2"></span>
      
      <span class="span1"></span>

  <header class="card-header">
    <h3 class="job-title">Tele Calling Executive</h3>
    <p class="job-code">PPC/TCE/1181208</p>
    <p class="job-location">SalesSS - Erode</p>
  </header>

  <h2 class="card__title">1-2 years of experience required.</h2>
  <p class="job-dates">Posted On: 29 Oct 2024 | End Date: 05 Dec 2024</p>
  
  <p class="card__apply">
    <i class="fas fa-briefcase rotating-icon"></i>
    <a class="card__link"  class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">Apply Now <i class="fas fa-arrow-right"></i></a>
  </p>
    </div>


    <!--*********** card************ -->

    <div class="cardR card-1 col-lg-5" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300">
      <span class="span3"></span>
      <span class="span2"></span>
      
      <span class="span1"></span>

  <header class="card-header">
    <h3 class="job-title">Tele Calling Executive</h3>
    <p class="job-code">PPC/TCE/1181208</p>
    <p class="job-location">SalesSS - Erode</p>
  </header>

  <h2 class="card__title">1-2 years of experience required.</h2>
  <p class="job-dates">Posted On: 29 Oct 2024 | End Date: 05 Dec 2024</p>
  
  <p class="card__apply">
    <i class="fas fa-briefcase rotating-icon"></i>
    <a class="card__link"  class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">Apply Now <i class="fas fa-arrow-right"></i></a>
  </p>
    </div>

 <!--*********** card************ -->
    <div class="cardR card-1 col-lg-5" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300">
      <span class="span3"></span>
      <span class="span2"></span>
      
      <span class="span1"></span>

  <header class="card-header">
    <h3 class="job-title">Tele Calling Executive</h3>
    <p class="job-code">PPC/TCE/1181208</p>
    <p class="job-location">SalesSS - Erode</p>
  </header>

  <h2 class="card__title">1-2 years of experience required.</h2>
  <p class="job-dates">Posted On: 29 Oct 2024 | End Date: 05 Dec 2024</p>
  
  <p class="card__apply">
    <i class="fas fa-briefcase rotating-icon"></i>
    <a class="card__link"  class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">Apply Now <i class="fas fa-arrow-right"></i></a>
  </p>
    </div>



  </div>
  <div style="display: flex; justify-content: center;">
    <hr style="width: 80%;">
  </div>
 
</div>

<!-- contact section -->


 <!-- Contact Section -->
 <section class="animated-bg text-center m-3">
  <div class="container">
    <h2 class="contact-header">Join Our Team</h2>
    <p class="contact-text">
      At <strong>Drops Chemicals</strong>, we’re always looking for dedicated professionals who are passionate about quality and innovation. 
      Whether you're a skilled technician, a logistics expert, or a recent graduate eager to start your career, 
      we provide opportunities to grow and contribute to cutting-edge projects that shape industries worldwide.
    </p>
    <p class="contact-text">
      Reach out to us for career inquiries, or explore current openings to find your fit. Together, we can build something extraordinary.
    </p>
    <!-- Button to Open Modal -->
    <button type="button" class="btn btn-contact" data-bs-toggle="modal" data-bs-target="#careerFormModal">
      Join Now
    </button>
  </div>
</section>

<!-- Modal for Career Application Form -->
<div class="modal fade" id="careerFormModal" tabindex="-1" aria-labelledby="careerFormLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="careerFormLabel">Career Appeal Form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="<?php echo e(route('job.submit')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="fullName" class="form-label">Full Name</label>
        <input type="text" class="form-control" id="fullName" name="full_name" placeholder="Enter your full name" required>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
    </div>
    <div class="mb-3">
        <label for="position" class="form-label">What position are you applying for?</label>
        <input type="text" class="form-control" id="position" name="position" placeholder="Enter position" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Specify your current employment status</label>
        <div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="employment_status" id="employed" value="employed" required>
                <label class="form-check-label" for="employed">Employed</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="employment_status" id="unemployed" value="unemployed">
                <label class="form-check-label" for="unemployed">Unemployed</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="employment_status" id="selfEmployed" value="self-employed">
                <label class="form-check-label" for="selfEmployed">Self Employed</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="employment_status" id="student" value="student">
                <label class="form-check-label" for="student">Student</label>
            </div>
        </div>
    </div>
    <div class="mb-3">
        <label for="resume" class="form-label">Upload your resume</label>
        <input type="file" class="form-control" id="resume" name="resume" required>
    </div>
    <button type="submit" class="btn btn-primary w-100">Submit</button>
</form>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

      </div>
      
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
   :root {
  --font1: Poppins;
}
h1,h2,h3,a,span{
  font-family: var(--font1);
}
a{
  font-size: 18px !important;
}

 /* font color changing */
 .font-color-footer {
            color: rgb(91, 185, 223);

        }



  /* Animated Background */
  .animated-bg {
    animation: backgroundChange 10s infinite alternate;
    padding: 50px 0;
    transition: all 0.3s ease;
  }

  @keyframes backgroundChange {
    0% {  background: radial-gradient(#1fe4f5, #3fbafe); } /* Light Gray */
    25% {  background: radial-gradient(#1fe4f5, #3fbafe); } /* Blue */
    50% {  background: radial-gradient(#1fe4f5, #3fbafe); } /* Gray */
    75% {  background: radial-gradient(#1fe4f5, #3fbafe);} /* Yellow */
    100% {  background: radial-gradient(#1fe4f5, #3fbafe);} /* Green */
  }

  .contact-header {
    font-size: 2rem;
    font-weight: bold;
    color: #ffffff; 
  }

  .contact-text {
    font-size: 1.1rem;
    color: #ffffff;
    margin-bottom: 30px;
  }

  .btn-contact {
    font-size: 1rem;
    padding: 10px 20px;
    border-radius: 30px;
    background-color: #ffffff;
    color: #007bff;
    text-transform: uppercase;
    transition: all 0.3s ease;
  }

  .btn-contact:hover {
    background-color: #f8f9fa;
    color: #007bff;
  }


  /* icon rotation animation start */
  @keyframes rotateAnimation {
    0% { transform: translateX(0); } 
  50% { transform: translateX(10px); }
  100% { transform: translateX(0); } 
}

.rotating-icon {
  display: inline-block; 
  margin-right: 10px;
  animation: rotateAnimation 2s linear infinite; 
  font-size: 1.2em; 
  color: #007bff;
}


/* icon rotation animation End */
</style>
<link rel="stylesheet" href="<?php echo e(asset('/css/career.css')); ?>">

  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dropchemical\dropschemicals\resources\views/drops/career.blade.php ENDPATH**/ ?>