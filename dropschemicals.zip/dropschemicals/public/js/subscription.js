document.getElementById('subscribe-button').addEventListener('click', function () {
    const email = document.getElementById('email').value;
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;


fetch('{{ route("subscribe") }}', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': csrfToken,  // Correct header for CSRF token
    },
    body: JSON.stringify({ email: email }),  // Sending email as the request body
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        alert(data.message);  // Success message
        document.getElementById('email').value = '';  // Clear the input field
    } else {
        alert(data.message);  // Error message
        console.error(data.error);  // Log detailed error for debugging
    }
})
.catch(error => {
    alert('An error occurred. Please try again.');
    console.error(error);
});

});
