@extends('layouts.app')

@section('content')
  <!--=====HERO AREA START=======-->

  <div class="common-hero" style="background-image: url('{{asset('/image/bg/bg-slide-img2.png')}}');overflow-x: hidden;" id="contactself">
    <div class="container">
      <div class="row">
        <div class="col-lg-10">
          <div class="common-hero-heading">
            <h1 class="text-60 sm:text-30 md:text-30 leading-56 font-semibold white">Contact Us</h1>
            <div class="page-change">
              <ul>
                <li class="inline-block"><a href="{{route('/')}}"
                    class="inline-block text-16 leading-16 white font-semibold">Home</a></li>
                <li class="inline-block arrow text-16 leading-16 white font-normal"><i
                    class="fa-solid fa-angle-right"></i></li>
                <li class="inline-block text-16 leading-16 white font-normal">Contact Us</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--=====HERO AREA END=======-->

  <!--=====CONTACT AREA START=======-->

  <!-- <div class="sp" > -->
    <div class="container-fluid bg-light"  >
      <div class="row py-2 ">
        <div class="col-lg-6 px-2" data-aos="fade-right">
          <div class="mt-15 p-3  mb-5 text-center" style=" font-family: Georgia, 'Times New Roman', Times, serif;">
            <h3 class="mb-3">Our Team</h3>
            <div class="img-container">
              <img class="p-2 img-fluid" src="{{asset('/img/New folder/img/contact-img-1.png')}}" alt="Contact Image"
                style="background-color: #fff;">
            </div>
          </div>

          <div class="contact-time mt-20 mx-5">
            <h5 class="text-20 font-semibold title1 leading-20">Operating Hours</h5>
            <ul>
              <li class="text-16 font-normal pera1 leading-16"><img src="{{asset('/img/icons/time.svg')}}" alt=""> Monday -
                Saturday</li>
              <li class="text-16 font-normal pera1 leading-16"><img src="{{asset('/img/icons/time.svg')}}" alt=""> 9:00 Am -
                6:00 Pm </li>
            </ul>
            <div class="blog2-divider"></div>

            <div class="contact-box-p mt-30">
              <div class="icon">
                <img src="{{asset('/img/icons/contact-icon1.svg')}}" alt="">
              </div>
              <div class="heading ml-16">
                <h3 class="text-20 font-semibold title1 leading-20">Warehouse Address</h3>
                <a href="https://www.google.com/maps?q=7/8-5+Athikadavu+Road,+Keeranatham,+Tamil+Nadu+641035"
                  class="text-16 font-normal inline-block mt-3 pera1 leading-16" target="_self">
                  7/8-5, Athikadavu Road,<br> Keeranatham, Tamil Nadu 641035, India
                </a>
              </div>
            </div>
            <div class="blog2-divider"></div>

            <div class="contact-box-p mt-30">
              <div class="icon">
                <img src="{{asset('/img/icons/contact-icon2.svg')}}" alt="">
              </div>
              <div class="heading ml-16">
                <h3 class="text-20 font-semibold title1 leading-20">Contact-Numbers</h3>
                <a href="tel:91 96775 22201" class="text-16 font-normal inline-block mt-3 pera1 leading-16">96775
                  22201 /</a>
                  <a href="tel:91 96775 22201" class="text-16 font-normal inline-block mt-3 pera1 leading-16">96775 66652</a> <br>
              </div>
            </div>
            <div class="blog2-divider"></div>

            <div class="contact-box-p mt-30">
              <div class="icon">
                <img src="{{asset('/img/icons/contact-icon3.svg')}}" alt="">
              </div>
              <div class="heading ml-16">
                <h3 class="text-20 font-semibold title1 leading-20">Need Help or Have Feedback</h3>
                <a href="mailto:info@dropschemicals.com"
                  class="text-16 font-normal inline-block mt-3 pera1 leading-16">info@dropschemicals</a>
              </div>
            </div>
            <div class="blog2-divider"></div>




          </div>
        </div>

        <div class="col-lg-6" data-aos="fade-left">
          <div class="mt-15 p-3 text-center" style="background-color:rgb(238, 241, 241); font-family: Georgia, 'Times New Roman', Times, serif;">
            <h3 class="mb-3">Contact</h3>
          </div>
          <div class="contact-form sm:mt-30 md:mt-30  py-5 ">
          <form action="{{ route('contact.sendEmail') }}" method="POST">
    @csrf
    <div class="row">
        <!-- First Name -->
        <div class="col-lg-6 mt-20">
            <div class="single-input">
                <label>First Name*</label>
                <input type="text" placeholder="First Name" name="first_name" id="first-name" required>
            </div>
        </div>

        <!-- Last Name -->
        <div class="col-lg-6 mt-20">
            <div class="single-input">
                <label>Last Name*</label>
                <input type="text" placeholder="Last Name" name="last_name" required>
            </div>
        </div>

        <!-- Email -->
        <div class="col-lg-6">
            <div class="single-input mt-20">
                <label>Email Address*</label>
                <input type="email" placeholder="Email" name="email" required>
            </div>
        </div>

        <!-- Phone Number -->
        <div class="col-lg-6">
            <div class="single-input mt-20">
                <label>Phone Number*</label>
                <input type="tel" id="phone-number" name="phone_number" placeholder="Phone Number" maxlength="10" pattern="^\d{10}$" oninput="this.value = this.value.replace(/[^0-9]/g, '');" required>
            </div>
        </div>

        <!-- Location -->
        <div class="col-lg-6">
            <div class="single-input mt-20">
                <label>Location*</label>
                <input type="text" placeholder="Location" name="location" required>
            </div>
        </div>

        <!-- Company -->
        <div class="col-lg-6">
            <div class="single-input mt-20">
                <label>Company Name*</label>
                <input type="text" placeholder="Company" name="company" required>
            </div>
        </div>

        <!-- Product -->
        <div class="col-lg-6">
            <div class="single-input mt-20">
                <label>Product*</label>
                <input type="text" placeholder="Product" name="product" required>
            </div>
        </div>

        <!-- Quantity -->
        <div class="col-lg-6">
            <div class="single-input mt-20">
                <label>Quantity*</label>
                <input type="text" placeholder="Quantity" name="quantity" required>
            </div>
        </div>

        <!-- Type of Industry -->
        <div class="col-lg-6">
            <div class="single-input mt-20">
                <label>Type of Industry*</label>
                <input type="text" placeholder="Type of Industry" name="industry" required>
            </div>
        </div>

        <!-- Message -->
        <div class="col-lg-12">
            <div class="single-input mt-20">
                <label>Message</label>
                <textarea rows="5" placeholder="Type your message..." name="message"></textarea>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="col-lg-12 mt-20" style="text-align:center">
            <button type="submit" class="inline-block white text-16 leading-16 font-semibold btnr">
                Send
            </button>
        </div>
    </div>
</form>
@if(session('success'))
    <div style="color: green;">
        {{ session('success') }}
    </div>
@endif


          </div>

        </div>
      </div>
    </div>
  <!-- </div> -->
  <!--=====CONTACT AREA END=======-->



  <div class="border4"></div>
  <!-- feedback form start -->

  <div class=" p-5" data-aos="fade-left" style="background:linear-gradient(109.6deg, rgb(163, 217, 207) 11.2%, rgb(4, 178, 217) 100.2%);;color:#fff" id="feedbackSection" >
    <div class="my-5 container" >
        <div class="row align-items-center" style="font-family:Georgia, 'Times New Roman', Times, serif;color:black">
            <h1 class="text-center my-4">Feedback</h1>
<div class="row">

  <div class="col-lg-6 p-4">
    
    
    <div class="container " >
     
      <ul class="ulr">
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Quality Assurance:</strong> <br> Ensure consistent quality of raw materials and final products through rigorous testing protocols.</li>
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Efficiency in Production:</strong> <br>  Optimize processes to reduce waste and improve yield.</li>
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Sustainability:</strong> <br>Adopt eco-friendly practices to minimize environmental impact.</li>
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Supply Chain Reliability:</strong>  <br>Maintain strong supplier relationships and efficient logistics systems.</li>
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Customer-Centric Approach:</strong> <br> Customize products to meet specific client needs and provide excellent technical support.</li>
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Innovation:</strong> <br> Invest in R&D for new formulations and collaborate with research institutions.</li>
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Safety:</strong>  <br>Follow strict safety protocols for workers and product handling.</li>
        <li class="col-md-12 p-4" data-aos="flip-left" data-aos-duration="1200" data-aos-delay="300"><strong>Cost Management:</strong> <br> Source raw materials strategically and review processes for cost-saving opportunities.</li>
      </ul>
    </div>
  </div>
          
            <div class="col-lg-6 p-4">
 
            <form action="{{ route('feedback.submit') }}" method="POST">
                    <!-- Company Details -->
                    @csrf
                   <div class="row">
                    <div class="mb-3 col-md-6  ">
                        <label for="companyName" class="form-label">Your Company Name:</label>
                        <input type="text" class="form-control" id="companyName" name="companyName" required>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label for="date" class="form-label">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" required>
                    </div>
                  </div>
                    <div class="mb-3 col-lg-12">
                        <label for="surveyBy" class="form-label">Survey Completed by:</label>
                        <input type="text" class="form-control" id="surveyBy" name="surveyBy" required>
                    </div>
               
                  
                    <div class=" row">
                        <!-- Phone input -->
                        <div class=" col-md-6 ">
                            <label for="phone" class="form-label">Content No:</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required>
                        </div>
                        <!-- Email input -->
                        <div class=" col-md-6">
                            <label for="email" class="form-label">E-mail:</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                    </div>

                    <!-- Questions -->
                    <div class="mb-3">
                        <label for="products" class="form-label">1. What products, and or services did you purchase from Drops Chemicals?</label>
                        <textarea class="form-control" id="products" name="products" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">2. Was your purchasing experience with Drops Chemicals positive?</label>
                        <textarea class="form-control" id="experience" name="experience" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">3. Please rate the following supplier performance criteria:</label>
                        <div class="row g-3">
                            <!-- Price -->
                            <div class="col-md-6">
                                <label for="price" class="form-label">Price:</label>
                                <select class="form-control w-100" id="price" name="price">
                                    <option selected>-- Select --</option>
                                    <option>Excellent</option>
                                    <option>Good</option>
                                    <option>Average</option>
                                    <option>Poor</option>
                                </select>
                            </div>
                            <!-- Quality -->
                            <div class="col-md-6">
                                <label for="quality" class="form-label">Quality:</label>
                                <select class="form-control w-100" id="quality" name="quality">
                                    <option selected>-- Select --</option>
                                    <option>Excellent</option>
                                    <option>Good</option>
                                    <option>Average</option>
                                    <option>Poor</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">4. Did the products purchased meet your expectations?</label>
                        <textarea class="form-control" id="expectations" name="expectations" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">5. Please give us suggestions on how we can serve you better:</label>
                        <textarea class="form-control" id="suggestions" name="suggestions" rows="3"></textarea>
                    </div>

                    <!-- Submit and Clear -->
                    <div class="d-flex justify-content-center gap-2">
                        <button type="reset" class="btn btn-secondary">Clear</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
                @if(session('success1'))
                <div style="color: green;">
                {{ session('success1') }}
                 </div>
                  @endif
            </div>
 
         
         </div>
            
        </div>
    </div>
</div>
    <!-- feedback form end -->

 
 <!-- google form start -->

  <div class="contact-map-page mx-2 my-3">
    <iframe
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.9095463964417!2d77.0026573!3d11.1221596!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba8f7c243f57419%3A0xa18db41866366ed8!2sDrops%20Chemicals!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
      width="100%" height="450" style="border: 2px;" allowfullscreen="" loading="lazy"
      referrerpolicy="no-referrer-when-downgrade">
    </iframe>
  </div>

  <!-- google form end -->



@endsection

@push('styles')
<style>

:root {
  --font1: Poppins;
}
h1,h2,h3,a,span{
  font-family: var(--font1);
}
a{
  font-size: 18px !important;
}


 /* font color changing */
 .font-color-footer {
            color: rgb(91, 185, 223);

        }

        .ulr{
          text-align: center;
        }


/* feedback animation */

.ulr li:nth-child(odd) {
  background: linear-gradient(45deg,#87cefa, #f0f8ff);
  color: #333;
  transition: background 1s ease, color 0.5s ease;
  /* margin: 5px; */
  border-radius: 5px;
  min-width:200px;
    }

  .ulr li:nth-child(even) {
    background: linear-gradient(45deg, #f0f8ff, #87cefa);
  color: #333;
  transition: background 1s ease, color 0.5s ease;
  /* margin: 5px; */
  border-radius: 5px;
  min-width:200px;
    }

    .ulr li:hover {
      background: linear-gradient(45deg, #4682b4, #1e90ff);
  color: #fff;
    }

 /* Shadow box effect */
.shadow-box {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Light shadow effect */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

/* Shake animation */@keyframes shake {
    0% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    50% { transform: translateX(5px); }
    75% { transform: translateX(-5px); }
    100% { transform: translateX(0); }
}

/* Apply shake animation */
.animate-shake:hover {
    animation: shake 0.5s;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3); /* Darker shadow on hover */
}
.btnr{
  padding:12px 24px;background-color:rgb(47, 47, 255);border:none;border-radius: 5px;
}
.btnr:hover{
 background-color: blue;
 color: #fff;
}


</style>

   
@endpush

@push('scripts')
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const urlParams = new URLSearchParams(window.location.search);

        // Check for 'id=feed'
        if (urlParams.get('id') === 'feed') {
            const feedbackSection = document.getElementById("feedbackSection");

            if (feedbackSection) {
                feedbackSection.style.display = "block"; // Show the section

                setTimeout(() => {
                    feedbackSection.scrollIntoView({ behavior: "smooth" });
                    feedbackSection.focus();
                }, 500);
            }
        }
    });
</script>
@endpush