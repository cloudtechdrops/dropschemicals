@extends('layouts.app')

@section('content')
    <!--=====HERO AREA START=======-->

  <div class="hero1-slider">
    <div class="hero1-single-slider hero1-bg1 flex items-center md:inline-block sm:inline-block _relative">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="main-heading1 mt-60">
              <h1 class="md:text-40 text-60 font-semibold white" style="font-family:Poppins;">Advanced Manufacturing & Reliable Supply Solutions</h1>
              <p class="mt-24 text-16 leading-26 white font-normal">Our advanced manufacturing expertise and supply
                chain solutions ensure precision, quality, and reliability. From efficient production to seamless
                material delivery, we are your trusted partner in success</p>
              <div class="buttons mt-30">
                <a class="theme-btn1" href="{{route('ourservices')}}">Our Service <span class="arrow1"><i
                      class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                      class="fa-solid fa-arrow-right"></i></span></a>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="main-image d-none d-lg-block">
        <img src="{{asset('img/hero/hero1-main-image.png')}}" alt="" >
      </div>
      <div class="main-image d-block d-lg-none">
        <img src="{{asset('/img/hero/hero1-mobile.png')}}" alt="">
      </div>
    </div>

    <div class="hero1-single-slider hero1-bg2 flex md:inline-block sm:inline-block items-center _relative">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="main-heading1 mt-60">
              <h1 class="md:text-40 text-60 font-semibold white">Precision Manufacturing and Quality Material Supplies
                Results</h1>
              <p class="mt-24 text-16 leading-26 white font-normal">Our advanced manufacturing processes and supply
                services are tailored to meet your needs with precision and reliability. From cutting-edge production to
                dependable material delivery, we provide solutions you can trust,</p>
              <div class="buttons mt-30">


                <a class="theme-btn2" href="{{route('contact')}}">Contact Us<span class="arrow1"><i
                      class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                      class="fa-solid fa-arrow-right"></i></span></a>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="main-image d-none d-lg-block">
        <img src="{{asset('/img/hero/hero1-main-image2.png')}}" alt="">
      </div>
      <div class="main-image d-block d-lg-none">
        <img src="{{asset('/img/hero/hero1-mobile.png')}}" alt="">
      </div>
    </div>

    <div class="hero1-single-slider hero1-bg3 flex items-center md:inline-block sm:inline-block  _relative">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="main-heading1 mt-60">
              <h1 class="md:text-40 text-60 font-semibold white">Excellence in Manufacturing and Material Supplies</h1>
              <p class="mt-24 text-16 leading-26 white font-normal">Our advanced manufacturing and supply solutions are
                designed to deliver precision, reliability, and trust. From high-quality production to efficient
                material sourcing, we ensure excellence in every aspect of your operations</p>
             
            </div>
          </div>
        </div>
      </div>
      <div class="main-image d-none d-lg-block">
        <img src="{{asset('/img/hero/hero1-main-image3.png')}}" alt="">
      </div>
      <div class="main-image d-block d-lg-none">
        <img src="{{asset('/img/hero/hero1-mobile.png')}}" alt="">
      </div>
    </div>

  </div>

  <!--=====HERO AREA END=======-->


  <!--=====ABOUT AREA START=======-->

  <div class="about1 p-3 my-2" style="background: var(--secondary-gradient);background-position: 100%;background-size: cover;width:100%;overflow-x: hidden;">
    <div class="heading1 pl-50 md:pl-0 xs:pl-0 md:pt-30 sm:pt-20 " style="text-align: center; ">
      <span class="span1 text-35 leading-30 title1 font-normal mb-16" data-aos="fade-left" data-aos-duration="700"
        style="color:blue;font-size:2em;font-weight:bold !important;font-family: Georgia, 'Times New Roman', Times, serif;"><img src="{{asset('/img/icons/slide-icon.ico')}}" alt="">
        Welcome to Drops Chemicals</span>
    </div>
    <div class="container">

      <div class="row align-items-center">
        <div class="col-lg-6" style="overflow: hidden;align-items: center;" >  
        <div class="about1-images" style="background-image:url('{{ asset('image/svg/blob.png') }}');background-repeat: no-repeat ;background-position: center;background-size: contain;position: relative;">
          
            <div class="image1 absolute image-anime reveal  homer  resize-1"
               id="resize-1">
              <img src="{{asset('/img/about/about1-image1.png')}}" alt="" id="resize-img" >
            </div>
            <div class="image1 absolute image-anime reveal  homer resize-2"
              id="resize-1">
              <img src="{{asset('img/about/about1-image2.png')}}" alt="" id="resize-img" >
            </div>
            <div class="image1 absolute  image-anime reveal homer resize-3"
               id="resize-1">
              <img src="{{asset('/img/about/about1-image3.png')}}" alt="" id="resize-img">
            </div>
         
          </div>
        </div>
      

        <div class="col-lg-6">
          <div class="heading1 pl-15 md:pl-0 xs:pl-0 md:pt-15 sm:pt-10">


            <h2 class="text-25 sm:text-30 md:text-30 leading-56 font-semibold title1 text-anime-style-3 white"
              style="background:var(--secondary-gradient);color:black;font-family: Georgia, 'Times New Roman', Times, serif;position: relative; "> Expert
              Manufacturing & Supply</h2>

            <p class="mt-16 text-16 font-normal pera1 leading-26 p-2" data-aos-delay="200" data-aos="fade-left"
              data-aos-duration="800" style="background:var(--secondary-gradient) ;color: black;">DropsChemicals
              specializes in high-precision manufacturing and reliable supply services for various industries. With an
              experienced team and state-of-the-art processes, we ensure every product we deliver meets the highest
              standards. We are committed to supporting your success with quality and reliability.</p>
            <p class="mt-16 text-16 font-normal pera1 leading-26 p-2 " data-aos-delay="200" data-aos="fade-left"
              data-aos-duration="1000" style="background:var(--secondary-gradientt);color: black; ;">We pride ourselves
              on our meticulous approach to manufacturing and supply solutions. Our state-of-the-art facilities are
              equipped with advanced technologies, enabling us to deliver high-quality products and reliable supply
              services across diverse industries</p>


            <div class="button mt-30" data-aos="fade-left" data-aos-duration="800" data-aos-delay="200">
              <a class="theme-btn3" href="{{route('ourservices')}}">Our Services <span class="arrow1"><i
                    class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                    class="fa-solid fa-arrow-right"></i></span></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--=====ABOUT AREA END=======-->

  <!--=====SERVICE AREA START=======-->

  <div class="service sp" style="background: var(--primary-gradient);">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 m-auto text-center">
          <div class="heading1">
            <span class="span1 text-22 leading-18 title1 font-normal mb-16" data-aos="fade-left"
              data-aos-duration="700">Our Services </span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1 text-anime-style-3 white">
              Comprehensive Manufacturing & Supply Solutions</h2>
          </div>
        </div>
      </div>
      <div class="space30"></div>
      <!-- Agro & Aquaculture -->
      <div class="row">
        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
          <div class="service-box1 mt-30">
            <div class="image image-anime image-clr">
              <img class="w-full" src="{{asset('/img/home/natural.png')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}" class="text-20 leading-20 font-semibold title1">Agro &
                  Aquaculture</a></h4>
              <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26">We supply high-quality agrochemicals used in
                agriculture to improve crop yields and diseases.</p>
              <a href="{{route('ourservices')}}" class="learn text-16 leading-16 font-semibold title1">
                Read More <span class="arrow1">
                
                  <i class="fa-solid fa-arrow-right"></i>
                </span><span class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
            </div>
          </div>
        </div>

        <!-- Modal -->
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title text-primary" id="exampleModalLabel">Agro & Aquaculture Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <img src="{{asset('/img/home/natural.png')}}" alt="Agro & Aquaculture" class="img-fluid m-3">

                <p style="padding:15px;margin: 5px; background: var(--secondary-gradient);">We supply high-quality
                  agrochemicals used in agriculture to improve crop yields and protect plants from pests and diseases.
                  Our range of aquaculture products and agrochemicals includes herbicides, insecticides, and fungicides,
                  among others.</p>

                <!-- Industry List -->
                <h5 class="text-primary"> We Serve:</h5>
                <ul style="padding:10px;background:var(--secondary-gradient);">
                  <li>🌾 Potential Farmers</li>
                  <li>🌱 Agricultural Clusters</li>
                  <li>🌊 Hydro Farms</li>
                  <li>🐟 Fish Farms</li>
                  <li>🐔 Poultry Farms</li>
                </ul>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>


        <!-- Agro & Aquaculture end -->


        <!-- Food Processing Chemicals start -->

        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="1000" data-aos-delay="300">
          <div class="service-box1 mt-30">
            <div class="image image-anime ">
              <img class="w-full" src="{{asset('/img/home/img (3).png')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}"" class="text-20 leading-20 font-semibold title1">Food Processing
                  Chemicals</a></h4>
              <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26">We offer high-quality food processing
                chemicals for the food industry.</p>
              <a href="{{route('ourservices')}}" class="learn text-16 leading-16 font-semibold title1">Read More <span
                  class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                    class="fa-solid fa-arrow-right"></i></span></a>

            </div>
          </div>
        </div>

        <!-- Modal for Food Processing Chemicals -->

        <div class="modal fade" id="exampleModalFood" tabindex="-1" aria-labelledby="exampleModalFoodLabel"
          aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title text-primary" id="exampleModalFoodLabel">Food Processing Chemicals Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body p-4">
                <!-- Image with Animation -->
                <img src="{{asset('/img/home/img (3).png')}}" alt="Food Processing Chemicals"
                  class="img-fluid mb-3 animated-image">

                <!-- Description -->
                <p style="padding:15px;margin: 5px; background: var(--secondary-gradient);">We offer a wide range of
                  high-quality food processing chemicals designed to enhance the production,
                  safety, and preservation of food products. These chemicals help ensure the quality and safety of food
                  while complying with industry standards.</p>

                <!-- Industry List with Emojis -->
                <h5 class="text-primary"> We Serve:</h5>
                <ul style="padding-left: 20px;" class="element3">
                  <li>🍹 Beverage Industries</li>
                  <li>🥛 Dairy Processing Units</li>
                  <li>🍬 Sugar Industries</li>
                  <li>🍲 Home Made Food Industries</li>
                  <li>🌾 Starch Industries (Sagoserve Industries)</li>
                </ul>
              </div>
              <div class="modal-footer">
                <!-- Blue button with padding and margin -->
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Food Processing Chemicals start -->


        <!--Basic Industrial Chemicals  -->
        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="700" data-aos-delay="300">
          <div class="service-box1 mt-30">
            <div class="image image-anime  image-clr">
              <img class="w-full" src="{{asset('/img/home/img (2).png')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}" class="text-20 leading-20 font-semibold title1">Basic Industrial
                  Chemicals</a></h4>
              <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26">We supply essential basic industrial
                chemicals, ensuring consistent quality and reliable performance.</p>
              <a href="{{route('ourservices')}}" class="learn text-16 leading-16 font-semibold title1">Read More <span
                  class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                    class="fa-solid fa-arrow-right"></i></span></a>
           
            </div>
          </div>
        </div>

        <!-- Modal for Basic Industrial Chemicals -->
        <!-- Modal -->
        <div class="modal fade" id="exampleModalBasic" tabindex="-1" aria-labelledby="exampleModalBasicLabel"
          aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title text-primary" id="exampleModalBasicLabel">Basic Industrial Chemicals Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">

                <img src="{{asset('/img/home/img (2).png')}}" alt="Food Processing Chemicals"
                  class="img-fluid mb-3 animated-image">

                <p style="padding:15px;margin: 5px; background: var(--secondary-gradient);">We supply essential basic
                  industrial chemicals, ensuring consistent quality and reliable performance
                  for a wide range of applications. Our chemicals are trusted by industries worldwide for their
                  effectiveness and reliability.</p>

                <!-- Industry List -->
                <h5 class="text-primary">Industries We Serve:</h5>
                <ul style="padding-left: 20px;" class="element3">
                  <li>🔩Aluminium Die Casting</li>
                  <li>🔩 Stainless Steel Casting</li>
                  <li>👗 Dying & Leather Units</li>
                  <li>🌡️ Radiators & Heat Exchanger Manufacturers</li>
                  <li>🧵 Textile Processing Units</li>
                  <li>📄 Paper Industries</li>
                </ul>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>



        <!-- Water Treatment Chemicals< -->

        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="800" data-aos-delay="300">
          <div class="service-box1 mt-30">
            <div class="image image-anime">
              <img class="w-full" src="{{asset('/img/home/img (1).png')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}" class="text-20 leading-20 font-semibold title1">Water Treatment
                  Chemicals</a></h4>
              <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26">We provide high-quality water treatment
                chemicals for effective and reliable water purification solutions.</p>
              <a href="{{route('ourservices')}}" class="learn text-16 leading-16 font-semibold title1">Read More <span
                  class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                    class="fa-solid fa-arrow-right"></i></span></a>
           
            </div>
          </div>
        </div>

        <!-- Modal for Water Treatment Chemicals -->
        <div class="modal fade" id="waterTreatmentModal" tabindex="-1" aria-labelledby="waterTreatmentModalLabel"
          aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title text-primary" id="waterTreatmentModalLabel">Water Treatment Chemicals Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">

                <img src="{{asset('/img/home/img (1).png')}}" alt="Food Processing Chemicals"
                  class="img-fluid mb-3 animated-image">
                <p style="padding:15px;margin: 5px; background: var(--secondary-gradient);">We offer a comprehensive
                  range of high-quality water treatment chemicals that ensure effective and
                  reliable water purification. Our products are designed to meet the needs of various industries,
                  improving water quality and helping in the safe and efficient treatment of water systems.</p>

                <!-- Industry List -->
                <h5 class="text-primary">Industries We Serve:</h5>
                <ul style="padding-left: 20px; " class="element3">
                  <li>🌊 Effluent Treatment Plants</li>
                  <li>🚰 Sewage Treatment Plants</li>
                  <li>💧 Waste Water Treatment Plants</li>
                  <li>💧Cooling Towers</li>
                  <li>🔥 Boilers</li>
                  <li>🔄 RO Plants</li>
                  <li>🏊 Swimming Pools</li>
                </ul>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>




        <!-- Hygiene Products -->

        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="1000" data-aos-delay="300">
          <div class="service-box1 mt-30">
            <div class="image image-anime  image-clr">
              <img class="w-full" src="{{asset('/img/home/img (4).png')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}"class="text-20 leading-20 font-semibold title1">Hygiene Products</a>
              </h4>
              <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26">We offer a wide range of hygiene products
                designed for cleanliness and safety.</p>
              <a href="{{route('ourservices')}}"
                class="learn text-16 leading-16 font-semibold title1" ">Read More <span class=" arrow1"><i
                  class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                    class="fa-solid fa-arrow-right"></i></span></a>

            </div>
          </div>
        </div>

        <!-- Modal for Hygiene Products -->
        <!-- Modal for Hygiene Products -->
        <div class="modal fade" id="hygieneProductsModal" tabindex="-1" aria-labelledby="hygieneProductsModalLabel"
          aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title text-primary" id="hygieneProductsModalLabel">Hygiene Products Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">

                <img src="{{asset('/img/home/img (4).png')}}" alt="Food Processing Chemicals"
                  class="img-fluid mb-3 animated-image">
                <p style="padding:15px;margin: 5px; background: var(--secondary-gradient);">Our wide range of hygiene
                  products ensures cleanliness and safety across various industries. We
                  provide cleaning agents, sanitizers, disinfectants, and more, all formulated to maintain a hygienic
                  environment. These products are essential in industries like healthcare, hospitality, food processing,
                  and more.</p>

                <!-- Industry List -->
                <h5 class="text-primary">Industries We Serve:</h5>
                <ul style="padding-left: 20px;" class="element3">
                  <li>💄 Cosmetic Industries</li>
                  <li>🧺 Laundry Care Industries</li>
                  <li>🏫 Institutes</li>
                  <li>🏨 Hotels</li>
                  <li>🏝️ Resorts</li>
                  <li>🏥 Hospitals</li>
                </ul>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>





        <!-- Solvents & Petrochemicals -->

        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="1200" data-aos-delay="300">
          <div class="service-box1 mt-30">
            <div class="image image-anime">
              <img class="w-full" src="{{asset('/img/home/img (5).png')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}" class="text-20 leading-20 font-semibold title1">Solvents &
                  Petrochemicals</a></h4>
              <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26">We supply high-quality solvents and
                petrochemicals for various industrial applications.</p>
              <a href="{{route('ourservices')}}" class="learn text-16 leading-16 font-semibold title1">Read More <span
                  class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                    class="fa-solid fa-arrow-right"></i></span></a>
          
            </div>
          </div>
        </div>


        <!-- Modal for Solvents & Petrochemicals -->
        <div class="modal fade" id="solventsModal" tabindex="-1" aria-labelledby="solventsModalLabel"
          aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title text-primary" id="solventsModalLabel">Solvents & Petrochemicals</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <img src="{{asset('/img/home/img%20(5).png')}}" alt="Food Processing Chemicals"
                  class="img-fluid mb-3 animated-image">

                <p style="padding:15px;margin: 5px; background: var(--secondary-gradient);">We provide top-tier solvents
                  and petrochemicals used in a variety of industrial processes. Our
                  products are widely used in manufacturing, pharmaceuticals, cleaning, and more. Our focus is on
                  supplying high-quality materials that meet stringent industry standards, ensuring reliability and
                  performance in all applications.</p>

                <!-- Industry List -->
                <h5 class="text-primary">Industries We Serve:</h5>
                <ul style="padding-left: 20px;" class="element3">
                  <li>🛢️ Rubber Industries</li>
                  <li>🎨 Paint Industries</li>
                  <li>🏭 Foundries</li>
                  <li>⚙️ Heavy Engineering Industries</li>
                  <li>🛢️ Lubricant Manufacturers</li>
                  <li>⛽ Oil Drilling Industries</li>
                  <li>💎 Gold Processing Units</li>
                </ul>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>



      </div>
    </div>
  </div>

  <!--=====SERVICE AREA END=======-->

  <!--=====SOLUTIONS AREA START=======-->

  <div class="solution1 sp" style="overflow: hidden;">
    <div class="container ">
      <div class="row">
        <div class="col-lg-8 m-auto text-center">
          <div class="heading1">
            <span class="span1 text-18 leading-18 title1 font-normal mb-16" data-aos="fade-left"
              data-aos-duration="700"><img src="{{asset('img/icons/slide-icon.ico')}}" alt=""> OUR COMPANY</span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1  text-anime-style-3"
              style="color:var(--blue-color);">Advanced Manufacturing & Supply Solutions Tailored to Your Industry's
              Needs </h2>
          </div>
        </div>
      </div>
      <div class="row mt-120 sm:mt-60 md:mt-60">
        <div class="col-lg-11 m-auto text-center" data-aos="fade-up" data-aos-duration="900">
          <div class="row">
            <div class="col-lg-4 d-none d-lg-block">
              <div class="icon-boxs-all1">
                <div class="icon-box left unic color1">
                  <div class="text">
                    <a href="{{route('ourservices')}}"class="text-20 leading-20 text-end font-semibold title1">Identifying
                      Needs</a>
                  </div>
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon1.svg')}}" alt="">
                  </div>
                </div>

                <div class="icon-box left middle color2">
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1">Market
                      Analysis</a>
                  </div>
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon2.svg')}}" alt="">
                  </div>
                </div>

                <div class="icon-box left unic color1">
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1"> On-Time
                      Delivery</a>
                  </div>
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon3.svg')}}" alt="">
                  </div>
                </div>
              </div>

            </div>
            <div class="col-lg-4">
              <div class="images">
                <div class="image" style="   background-color:transparent; box-shadow:none">
                  <img src="{{asset('/img/others/research-image1.png')}}" alt="">
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="icon-boxs-all2">
                <div class="icon-box2 right unic color2">
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon4.svg')}}" alt="">
                  </div>
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1">Payment
                      Process</a>
                  </div>
                </div>

                <div class="icon-box2 right middle color1">
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon5.svg')}}" alt="">
                  </div>
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1">Customer
                      Review</a>
                  </div>
                </div>

                <div class="icon-box2 right unic color2">
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon6.svg')}}" alt="">
                  </div>
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1">Custom
                      Testing <br> Solutions</a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 d-lg-none d-block">
              <div class="icon-boxs-all2">
                <div class="icon-box2 right unic color2">
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon1.svg')}}" alt="">
                  </div>
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1">Inspection
                      of Product <br> Quality <br> Packing</a>
                  </div>
                </div>

                <div class="icon-box2 right middle color1">
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon2.svg')}}" alt="">
                  </div>
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1">Trace
                      Element <br> Detection</a>
                  </div>
                </div>

                <div class="icon-box2 right unic color2">
                  <div class="icon">
                    <img src="{{asset('/img/icons/solution1-icon3.svg')}}" alt="">
                  </div>
                  <div class="text">
                    <a href="{{route('ourservices')}}" class="text-20 leading-20 text-end font-semibold title1">Specification
                      Review</a>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="space60"></div>

  <!--=====SOLUTIONS AREA END=======-->

  <!--=====PROCESS AREA START=======-->

  <div class="process sp _relative"
    style="background: linear-gradient(109.6deg, rgb(163, 217, 207) 11.2%, rgb(4, 178, 217) 100.2%);">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 m-auto text-center">
          <div class="heading1">
            <span class="span1 text-22 leading-18 title1 font-normal mb-16 " data-aos="fade-left"
              data-aos-duration="700"> Our Process</span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1 text-anime-style-3 white">How
              Drops Chemicals
              Works</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 d-none d-lg-block">
          <div class="video-area1 _relative"
            style="background-image: url('{{asset('/img/bg/video-area1-bg.jpg')}}'); background-size: cover; background-position: center;">

            <!-- Video Button -->
            <div id="play-btn" class="video-button play-btn">
              <a onclick="window.location.href='#'; return false;" target="_self"
                class="video-play-button">
                <span>

                </span>
              </a>
            </div>

          </div>
        </div>
      </div>


      <div class="row">
        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="1000">
          <div class="process-bottom-box text-center">
            <div class="icon">
              <img src="{{asset('/img/icons/solution-bottom-icon1.svg')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}"
                  class="text-20 leading-20 font-semibold title1 inline-block mt-24">Initial Consultation </a></h4>
              <p class="mt-16 mt-16 text-16 font-normal pera1 leading-26">We begin with an in-depth consultation to
                understand your specific needs and objectives.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="700">
          <div class="process-bottom-box text-center">
            <div class="icon">
              <img src="{{asset('/img/icons/solution-bottom-icon2.svg')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}"
                  class="text-20 leading-20 font-semibold title1 inline-block mt-24">Customized Testing Plan </a></h4>
              <p class="mt-16 mt-16 text-16 font-normal pera1 leading-26">Based on your requirements, we develop a
                customized testing plan tailored to your materials.</p>
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-6" data-aos="zoom-in-up" data-aos-duration="1000">
          <div class="process-bottom-box text-center">
            <div class="icon">
              <img src="{{asset('/img/icons/solution-bottom-icon3.svg')}}" alt="">
            </div>
            <div class="heading1">
              <h4><a href="{{route('ourservices')}}"
                  class="text-20 leading-20 font-semibold title1 inline-block mt-24">Consultation & Support </a></h4>
              <p class="mt-16 mt-16 text-16 font-normal pera1 leading-26">e offer follow-up consultations to review the
                results and discuss any <br> further steps.</p>
            </div>
          </div>
        </div>

      </div>

    </div>
  </div>

  <!--=====PROCESS AREA END=======-->


  <!-- =====BLOG AREA START=======-->

  <div class="blog1 sp" style="background: linear-gradient(108.3deg, rgb(244, 245, 247) 1%, rgb(244, 246, 247) 70.9%)">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 m-auto text-center">
          <div class="heading1">
            <span class="span1 text-22 leading-18 title1 font-normal mb-16" data-aos="fade-left"
              data-aos-duration=""><img src="{{asset('/img/icons/slide-icon.ico')}}" alt=""> Our Blog</span>
            <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1 text-anime-style-3 white"
              style="color:#0000FF">Explore
              the Latest Manufacturing Insights from DropsChemicals.</h2>
          </div>
        </div>
      </div>
      <div class="space30"></div>
      <div class="row">
        <div class="col-lg-6" data-aos-delay="350" data-aos="fade-up" data-aos-duration="1000">
          <div class="blog1-box _relative mt-30">
            <div class="image image-anime rounded-8 overflow-hidden _relative">
              <img class="transition4s w-full" src="{{asset('/img/home/imgfoot%20(1).jpg')}}" alt="">
            </div>
            <div class="heading-area">

              <h3><a href="{{route('blog')}}" class="text-24 leading-24 inline-block title1 font-semibold">Cutting-Edge
                  Manufacturing and Supply</a></h3>
              <p class=" mt-1 tex-16 font-normal pera1 leading-26 my-16 pt-16">Our cutting-edge manufacturing and supply
                services ensure top-quality products, driving success across industries.</p>

            </div>
          </div>
        </div>

        <div class="col-lg-6" data-aos-delay="50" data-aos="fade-up" data-aos-duration="1000">
          <div class="blog1-box _relative mt-30">
            <div class="image image-anime rounded-8 overflow-hidden _relative"
              style="padding: 10px; border: 5px solid white;">
              <img class="transition4s w-full" src="{{asset('/img/home/imgfoot (2).jpg')}}" alt="">
            </div>
            <div class="heading-area">

              <h3><a href="{{route('blog')}}" class="text-24 leading-24 inline-block title1 font-semibold"> Industry Regulations
                  in Manufacturing and Supplies</a></h3>
              <p class=" mt-1 tex-16 font-normal pera1 leading-26 my-16 pt-16 ">Industry regulations and innovations
                shape the future of manufacturing and supply operations, ensuring efficiency, sustainability, and growth
              </p>

            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!--=====BLOG AREA END=======-->
@endsection

@push('styles')
   
@endpush