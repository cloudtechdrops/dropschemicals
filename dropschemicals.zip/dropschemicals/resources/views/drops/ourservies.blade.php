@extends('layouts.app')

@section('content')

  <!--=====HERO AREA START=======-->

  <div class="common-hero" style="background-image: url('{{asset('/image/bg/bg\ \(7\).jpg')}}')" id="product">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="common-hero-heading">
                        <h1 class="text-60 sm:text-30 md:text-30 leading-56 font-semibold white">Our Services</h1>
                        <div class="page-change">
                            <ul>
                                <li class="inline-block"><a href="{{route('/')}}"
                                        class="inline-block text-16 leading-16 white font-semibold">Home</a></li>
                                <li class="inline-block arrow text-16 leading-16 white font-normal"><i
                                        class="fa-solid fa-angle-right"></i></li>
                                <li class="inline-block text-16 leading-16 white font-normal">Our Services</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--=====HERO AREA END=======-->

    <!--=====SERVICE AREA START=======-->

    <div class="service sp">
        <div class="container">

            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="research-box sm:mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img1.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="{{route('ourservices')}}" class="text-20 leading-20 font-semibold title1">Agro &
                                    Aquaculture
                                </a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"><strong> Agriculture
                                    Benefits:</strong> Nutrient-rich aquaculture waste boosts crop growth.
                                <br><strong> Aquaculture Benefits:</strong> Crop by-products provide cost-effective fish
                                feed.
                                <br><strong> Environmental Benefits: </strong>Integrated systems reduce waste and
                                pollution.
                            </p>
                            <a href="{{route('ourservices')}}" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box sm:mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img2.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#"
                                    class="text-20 leading-20 font-semibold title1">Detergent & Soap </a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"><strong> Health:</strong>
                                Promotes cleanlinessand enhances sanitation.
                                <br><strong> Hygiene:</strong> Soaps help reduce the spread of bacteriaand infections by
                                maintaining personal cleanliness.
                                <br><strong>Sanitation:</strong>Detergents ensure clean homes and public spaces,
                                promoting better overall health.
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box md:mt-30 sm:mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img3.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#" class="text-20 leading-20 font-semibold title1">Food
                                    Processing</a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"> <strong> Preservation:
                                </strong>Chemicals like sodium benzoate and sorbic acid help prevent microbial growth.
                                <br>
                                <strong> Safety: </strong>Food-grade chemicals ensure food safety by controlling
                                spoilage . <br>
                                <strong> Customization: </strong>Food processing chemicals are tailored to specific
                                needs.
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img4.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#" class="text-20 leading-20 font-semibold title1">Hygiene
                                    Products </a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"><strong> Soaps and Body
                                    Wash:</strong> For cleaning the skin and removing germs. <br> <strong>Surface
                                    Cleaners:</strong> Disinfectants for floors, counters, and other surfaces. <br>
                                <strong>Disease Prevention:</strong> Reduces the spread of bacteria, viruses, and other
                                pathogens.
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img5.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#" class="text-20 leading-20 font-semibold title1">Metal
                                    Finishing Industries </a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"> <strong> Anodizing:</strong>

                                Oxidizing the surface of aluminum to improve durability
                                <br> <strong> Corrosion Resistance:</strong>
                                Protects metal surfaces from rust
                                <br> <strong>Powder Coating:</strong>
                                Applying a durable, decorative layer using powdered paint.
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img6.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#"
                                    class="text-20 leading-20 font-semibold title1">Petrochemicals </a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"> <strong> Aromatics:</strong>
                                Benzene, and xylene (used in dyes, and synthetic fibers).
                                <br> <strong>Versatility: </strong>Forms the basis of numerous everyday products
                                <br> <strong> Efficiency: </strong>Provides cost-effective raw materials for large-scale
                                production
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img7.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#" class="text-20 leading-20 font-semibold title1">
                                    Poultry Farming</a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"> <strong> Protein
                                    Source:</strong>
                                Poultry meat and eggs are rich in high-quality protein <br>
                                <strong> Economic Benefits:</strong>
                                Provides income through meat and eggs. <br>
                                <strong> Employment Opportunities:</strong>
                                Creates jobs in farming, feed production, processing, and marketing.
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img8.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#" class="text-20 leading-20 font-semibold title1">Water
                                    Treatment
                                </a></h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"><strong>Safe Drinking
                                    Water:</strong>

                                Removes harmful contaminants.
                                <strong> Disease Prevention:</strong>

                                Reduces waterborne diseases caused by bacteria,and parasites.
                                <strong> Environmental Protection:</strong>

                                Treats wastewater before discharge to prevent pollution.
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="research-box mt-30">
                        <div class="image image-anime _relative">
                            <img class="w-full" src="{{asset('/img/research/research-box-img9.png')}}" alt="">
                        </div>
                        <div class="heading1">
                            <h4><a href="#" class="text-20 leading-20 font-semibold title1"></a>
                            </h4>
                            <p class="mb-20 mt-16 text-16 font-normal pera1 leading-26"> <strong> Versatility:</strong>

                                Widely applicable in diverse industries. <br>
                                <strong> Efficiency:</strong>

                                Speeds up chemical reactions and enhances product quality. <br>
                                <strong> Improved Product Performance:</strong>



                                Enhances the finish, texture, and longevity of products like paints.
                            </p>
                            <a href="#" class="learn text-16 leading-16 font-semibold title1">Read
                                More <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span><span
                                    class="arrow2"><i class="fa-solid fa-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!--=====SERVICE AREA END=======-->


    <!--===== product list=======-->

    <div class="team5 sp pb-3" id="formContainer" style="background: var(--primary-gradient); ">
        <div class="container" >
            <div class="row align-items-center ">
                <div class="col-lg-8 m-auto text-center">
                    <div class="heading1">
                        <span class="span1 text-18 leading-18 title1 font-normal mb-16 white"><img
                                src="{{asset('/img/New folder/icon/slide-icon.ico')}}" alt=""> Our services</span>
                        <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold white title1">Product List
                        </h2>


                    </div>


                </div>
                <div class="col-lg-12 m-auto text-center">

                    <div class="row p-3 m-2">
                        <div class="col-md-4">
                            <div class="image image-anime _relative">
                                <img class="w-full" src="{{asset('/img/research/research-box-img10.png')}}" alt="">
                            </div>
                        </div>
                        <div class="col-md-8" style="text-align:center">
                            <ul class="ulr">
                                <li class="text-18 leading-28 font-normal white  text-center m-4 ">
                                    We specialize in delivering high-quality chemicals to a wide range of industries,
                                    including manufacturing, pharmaceuticals, agriculture, and more.
                                </li>
                                <li class="text-18 leading-28 font-normal white  text-center m-4 para-1">
                                    Our extensive and diverse product portfolio is carefully tailored to meet the unique
                                    and ever-evolving needs of our customers, ensuring unparalleled satisfaction
                                </li>
                            </ul>

                        </div>
                    </div>
                </div>





                <div class="accordion pb-5" id="accordionExample">

                    <!-- Accordion Item 1 -->
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    AGRO & AQUACULTURE CHEMICALS
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="mb-3">
                                        <input type="text" id="productSearch1" class="form-control"
                                            placeholder="Search for a product...">
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-bodered  table-striped"  style="overflow-x:hidden" id="productTable1">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><a href="#">Ammonium Polyphosphate</a></td>
                                                    <td>67-56-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ammonium Chloride</a></td>
                                                    <td>67-56-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00002</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ammonium Sulphate (White)</a></td>
                                                    <td>67-56-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00003</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Biofertilizer</a></td>
                                                    <td>67-56-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00004</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Boran</a></td>
                                                    <td>67-56-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00005</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Boric Acid</a></td>
                                                    <td>67-56-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00006</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Calcium Carbonate</a></td>
                                                    <td>67-56-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00007</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Calcium Chloride</a></td>
                                                    <td>67-56-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00008</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Calcium Sulphate</a></td>
                                                    <td>67-56-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00009</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Calcium Nitrate</a></td>
                                                    <td>67-57-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00010</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Copper Sulphate</a></td>
                                                    <td>67-57-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00011</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Di Calcium Phosphate</a></td>
                                                    <td>67-57-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00012</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ferric Chloride</a></td>
                                                    <td>67-57-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00013</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ferrous Sulphate</a></td>
                                                    <td>67-57-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00014</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Fumaric Acid</a></td>
                                                    <td>67-57-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00015</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Humic Acid (Liquid / Powder)</a></td>
                                                    <td>67-57-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00016</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Humic Acid (Shiny Flakes)</a></td>
                                                    <td>67-57-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00017</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Hydrochloric Acid</a></td>
                                                    <td>67-57-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00018</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Hydrogen Peroxide</a></td>
                                                    <td>67-57-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00019</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Lime Powder</a></td>
                                                    <td>67-58-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00020</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Magnesium Phosphate</a></td>
                                                    <td>67-58-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00021</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Malic Acid</a></td>
                                                    <td>67-58-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00023</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Manganese Chloride</a></td>
                                                    <td>67-58-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00024</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Manganese Sulphate</a></td>
                                                    <td>67-58-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00025</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Magnesium Chloride</a></td>
                                                    <td>67-58-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00026</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Magnesium Sulphate</a></td>
                                                    <td>67-58-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00027</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Micronutrients</a></td>
                                                    <td>67-58-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00028</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Mixed Fertilizer</a></td>
                                                    <td>67-58-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00029</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Mono Ammonium Phosphate</a></td>
                                                    <td>67-59-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00030</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Mono Calcium Phosphate</a></td>
                                                    <td>67-59-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00031</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">NPK Fertilizers (All Series)</a></td>
                                                    <td>67-59-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00032</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Organix</a></td>
                                                    <td>67-59-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00033</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Phosphoric Acid</a></td>
                                                    <td>67-59-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00034</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Chloride</a></td>
                                                    <td>67-59-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00035</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Humate</a></td>
                                                    <td>67-59-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00036</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Hydroxide</a></td>
                                                    <td>67-59-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00037</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Nitrate</a></td>
                                                    <td>67-59-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00038</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Sulphate</a></td>
                                                    <td>67-59-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00039</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Silver Hydrogen Peroxide</a></td>
                                                    <td>67-60-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00040</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Chloride</a></td>
                                                    <td>67-60-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00041</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Hydroxide</a></td>
                                                    <td>67-60-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00042</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Nitrate</a></td>
                                                    <td>67-60-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00043</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Accordion Item 4 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    DETERGENT SOAP AND POWDERS & HYGIENE RAW MATERIALS
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="table-responsive">
                                        <div class="mb-3">
                                            <input type="text" id="productSearch2" class="form-control"
                                                placeholder="Search for a product...">
                                        </div>
                                        <table class="table table-bodered  table-striped" id="productTable2">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><a href="#">Acid Slurry (IPCL)</a></td>
                                                    <td>68-00-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00072</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Acid Slurry (TP)</a></td>
                                                    <td>68-00-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00073</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Acid Thickener</a></td>
                                                    <td>68-00-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00074</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Alphox 100 & 200 & All Grade</a></td>
                                                    <td>68-00-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00075</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">AOS Liquid/Paste/Powder</a></td>
                                                    <td>68-00-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00076</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">BKC (50% / 80%)</a></td>
                                                    <td>68-00-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00077</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Baking Soda (sodium bi carbonate)</a></td>
                                                    <td>68-00-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00078</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Butyl Acetate</a></td>
                                                    <td>68-00-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00079</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Caustic Soda</a></td>
                                                    <td>68-00-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00080</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Cetyl Acetate</a></td>
                                                    <td>68-01-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00081</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Coco Amido Propyl Betaine (CAPB)</a></td>
                                                    <td>68-01-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00082</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>

                                                <tr>
                                                    <td><a href="#">Coco Diethanol Amide (CDEA)</a></td>
                                                    <td>68-01-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00083</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">EGMS</a></td>
                                                    <td>68-01-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00084</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Enzyme</a></td>
                                                    <td>68-01-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00085</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ethylene Diamine Tetra Acetic Acid (EDTA)</a></td>
                                                    <td>68-01-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00086</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Fatty Acids</a></td>
                                                    <td>68-01-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00087</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Fatty Alcohols</a></td>
                                                    <td>68-01-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00088</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Filler Salt</a></td>
                                                    <td>68-01-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00089</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Free Flow Salt</a></td>
                                                    <td>68-01-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00090</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ginasul All Series</a></td>
                                                    <td>68-02-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00091</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ginol All Series</a></td>
                                                    <td>68-02-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00092</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>

                                                <tr>
                                                    <td><a href="#">Gum Resin</a></td>
                                                    <td>68-02-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00093</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Glycerine</a></td>
                                                    <td>68-02-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00094</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Hydrogen Peroxide (50%)</a></td>
                                                    <td>68-02-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00095</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Isopropyl Alcohol (IPA)</a></td>
                                                    <td>68-02-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00096</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Isopropyl Myristate</a></td>
                                                    <td>68-02-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00097</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Lauramide DEA</a></td>
                                                    <td>68-02-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00098</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Liquid Paraffin (Lite & Heavy)</a></td>
                                                    <td>68-02-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00099</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Lauric Acid</a></td>
                                                    <td>68-02-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00100</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Muristic</a></td>
                                                    <td>68-03-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00101</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">MEC - Mono Ethylene Sulphate</a></td>
                                                    <td>68-03-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00102</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Non-Ionic Surfactant</a></td>
                                                    <td>68-03-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00103</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Olic Acid</a></td>
                                                    <td>68-03-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00104</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Optical Brightener</a></td>
                                                    <td>68-03-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00105</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Oxytech</a></td>
                                                    <td>68-03-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00106</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Petroleum Jelly</a></td>
                                                    <td>68-03-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00107</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Phynoil Compound</a></td>
                                                    <td>68-03-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00108</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Pine Oil (32%)</a></td>
                                                    <td>68-03-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00109</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Silicon Oil</a></td>
                                                    <td>68-03-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00110</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Silky (Silicone)</a></td>
                                                    <td>68-04-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00111</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">SLES Series</a></td>
                                                    <td>68-04-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00112</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">SLES Paste 70%</a></td>
                                                    <td>68-04-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00113</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Soap Noodles</a></td>
                                                    <td>68-04-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00114</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Soda Ash</a></td>
                                                    <td>68-04-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00115</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Lauryl Sulfate (SLS Powder) - Needle</a></td>
                                                    <td>68-04-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00116</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Carboxy Methyl Cellulose</a></td>
                                                    <td>68-04-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00117</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Percarbonate</a></td>
                                                    <td>68-04-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00118</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Meta Silicate</a></td>
                                                    <td>68-04-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00119</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Sulphate</a></td>
                                                    <td>68-04-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00120</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Tri Poly Phosphate (STPP)</a></td>
                                                    <td>68-05-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00121</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Synthetic Thickener</a></td>
                                                    <td>68-05-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00122</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Soft Soap</a></td>
                                                    <td>68-05-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00123</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Tri Sodium Phosphate</a></td>
                                                    <td>68-05-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00124</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Tinopal</a></td>
                                                    <td>68-05-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00125</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Washing Soda (Soda Ash or Sodium Carbonate)</a></td>
                                                    <td>68-05-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00126</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <!-- Accordion Item 3 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    FOOD CHEMICALS
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="mb-3">
                                        <input type="text" id="productSearch3" class="form-control"
                                            placeholder="Search for a product...">
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table table-bodered  table-striped" id="productTable3">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><a href="#">Acetic Acid</a></td>
                                                    <td>67-61-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00054</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ammonium Bicarbonate</a></td>
                                                    <td>67-61-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00055</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Ascorbic Acid</a></td>
                                                    <td>67-61-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00056</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Calcium Chloride</a></td>
                                                    <td>67-61-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00057</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Calcium Propionate</a></td>
                                                    <td>67-61-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00058</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Citric Acid</a></td>
                                                    <td>67-61-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00059</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Final Gel</a></td>
                                                    <td>67-62-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00060</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Liquid Glucose</a></td>
                                                    <td>67-62-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00061</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Phosphoric Acid (Food Grade)</a></td>
                                                    <td>67-62-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00062</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Citrate</a></td>
                                                    <td>67-62-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00063</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Sorbate</a></td>
                                                    <td>67-62-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00064</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Aluminium Sulphate</a></td>
                                                    <td>67-62-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00065</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Benzoate</a></td>
                                                    <td>67-62-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00066</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Bicarbonate</a></td>
                                                    <td>67-62-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00067</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Citrate</a></td>
                                                    <td>67-62-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00068</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sorbic Acid</a></td>
                                                    <td>67-62-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00069</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sorbitol</a></td>
                                                    <td>67-63-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00070</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Xanthan Gum</a></td>
                                                    <td>67-63-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00071</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <!-- Accordion Item 5 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    HYGIENE
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="mb-3">
                                        <input type="text" id="productSearch4" class="form-control"
                                            placeholder="Search for a product...">
                                    </div>
                                    <table class="table table-bodered  table-striped" id="productTable4">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>CAS No</th>
                                                <th>MSDS</th>
                                                <th>Code</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <tr>
                                                <td><a href="#">Acid (HCL)</a></td>
                                                <td>68-05-6</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00127</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Bike Wash</a></td>
                                                <td>68-05-7</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00128</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Bleaching Powder</a></td>
                                                <td>68-05-8</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00129</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Car Spray</a></td>
                                                <td>68-05-9</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00130</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Car Wash</a></td>
                                                <td>68-06-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00131</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Chimney Cleaning Powder</a></td>
                                                <td>68-06-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00132</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Detergent Powder</a></td>
                                                <td>68-06-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00133</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Dishwash Liquid</a></td>
                                                <td>68-06-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00134</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Disinfectant</a></td>
                                                <td>68-06-4</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00135</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Fabric Conditioner</a></td>
                                                <td>68-06-5</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00136</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Fabric Wash</a></td>
                                                <td>68-06-6</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00137</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Floor Cleaner</a></td>
                                                <td>68-06-7</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00138</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Glass Cleaner</a></td>
                                                <td>68-06-8</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00139</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Hand Wash</a></td>
                                                <td>68-06-9</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00140</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Phenyl</a></td>
                                                <td>68-07-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00141</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Room Spray</a></td>
                                                <td>68-07-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00142</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Sanitizer (100, 200, 500, 5LTR)</a></td>
                                                <td>68-07-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00143</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Silver Disinfectant</a></td>
                                                <td>68-07-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00144</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Soap Oil</a></td>
                                                <td>68-07-4</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00145</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Tiles, Marble Cleaner</a></td>
                                                <td>68-07-5</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00146</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Toilet Cleaner</a></td>
                                                <td>68-07-6</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00147</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">Tyre Polish</a></td>
                                                <td>68-07-7</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00148</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Accordion Item 6 -->
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingSix">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                        METAL FINISHING CHEMICALS
                                    </button>
                                </h2>
                                <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <div class="mb-3">
                                            <input type="text" id="productSearch5" class="form-control"
                                                placeholder="Search for a product...">
                                        </div>
                                        <!-- Table 1 -->
                                        <h5 class="water-h3">Blackening</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Caustic Soda</td>
                                                    <td>1310-73-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>CS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Gloves</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>GL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Gum Boots</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>GB001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>HCL (Hydrochloric Acid)</td>
                                                    <td>7647-01-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HCL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nitric Acid</td>
                                                    <td>7697-37-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Sodium Nitrate</td>
                                                    <td>7631-99-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SN001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- Table 2 -->
                                        <h5 class="water-h3">Micro Plating (Gold, Silver)</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Antiscalent (RO Plant)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Copper Sulphate 24%</td>
                                                    <td>7758-98-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>CS24</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>DM Water (Deionized Water)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>DMW001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Hydrochloric Acid</td>
                                                    <td>7647-01-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HCL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Hydrogen Peroxide 50%</td>
                                                    <td>7722-84-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HP50</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nickel Sulphate</td>
                                                    <td>7786-81-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nitric Acid</td>
                                                    <td>7697-37-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Potassium Cyanide</td>
                                                    <td>151-50-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Sodium Cyanide</td>
                                                    <td>143-33-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Sulphuric Acid 98%</td>
                                                    <td>7664-93-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SA98</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- Table 3 -->
                                        <h5 class="water-h3">Nickel Plating</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Anode</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AN001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Boric Acid</td>
                                                    <td>10043-35-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>BA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Gloves</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>GL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>HCL (Hydrochloric Acid)</td>
                                                    <td>7647-01-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HCL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>(LR) Sulphuric Acid/Chrome Salt</td>
                                                    <td>7664-93-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nickel Additive</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nickel Brightener</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NB001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nickel Chloride</td>
                                                    <td>7718-54-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nickel Salt</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nickel Sulphate</td>
                                                    <td>7786-81-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NS004</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Soap</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SO001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Vazram</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>VZ001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Emery Wheel</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>EW001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- Table 4 -->
                                        <h5 class="water-h3">Non Cyanide (Zinc)</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Alkaline Mist Controller</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AMC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Alkaline Zinc Brightener</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AZB001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Alkaline Zinc Conditioner (Blue, Yellow, Zinc, Black Color)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AZC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Alkaline Zinc Salt</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AZS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Alkaline Booster</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AB001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Zinc Oxide</td>
                                                    <td>1314-13-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ZO001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- Table 5 -->
                                        <h5 class="water-h3">Other Finishing Chemicals Plating</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>3 in 1 Chemical</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>3IC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Ammonium Chloride</td>
                                                    <td>12125-02-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Boric Acid</td>
                                                    <td>10043-35-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>BA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Caustic Soda</td>
                                                    <td>1310-73-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>CS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Chromic Acid</td>
                                                    <td>7738-94-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>CA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Hydrochloric Acid</td>
                                                    <td>7647-01-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HCL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Hydrofluoric Acid (40% 60% High Strength)</td>
                                                    <td>7664-39-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HFA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nickel Sulphate</td>
                                                    <td>7786-81-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nitric Acid</td>
                                                    <td>7697-37-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Phosphoric Acid</td>
                                                    <td>7664-38-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Potassium Chloride</td>
                                                    <td>7447-40-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Sodium Nitrate</td>
                                                    <td>7631-99-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SN001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Sulphuric Acid</td>
                                                    <td>7664-93-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Zinc Salt (B)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ZS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- Table 6 -->
                                        <h5 class="water-h3">Phosphating</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Acid (HCL)</td>
                                                    <td>7647-01-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HCL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Manganese Phosphating</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>MP001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Zinc Phosphating Chemical (702)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ZP702</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Zinc Phosphating Chemical (602)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ZP602</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- Table 7 -->
                                        <h5 class="water-h3">Tin Plating</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Acid Tin Brightener - 684</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ATB684</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Brightener - 682</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>BR682</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Copper Sulphate</td>
                                                    <td>7758-99-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>CS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Sodium Stannate</td>
                                                    <td>12060-03-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Stannous Sulphate</td>
                                                    <td>7488-55-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SS001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Sulphuric Acid</td>
                                                    <td>7664-93-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>SA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- Table 8 -->
                                        <h5 class="water-h3">Zinc Plating</h5>
                                        <table class="table table-bodered  table-striped" id="productTable5">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Additive "M"</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AM001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Ammonium Chloride</td>
                                                    <td>12125-02-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>AC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Blue Passivation (Liquid)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>BPL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Blue Passivation (Powder)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>BPP001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Boric Acid</td>
                                                    <td>10043-35-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>BA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Brightener "R"</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>BRR001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>DM Water</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>DM001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Gloves</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>GLV001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>HCL (Hydrochloric Acid)</td>
                                                    <td>7647-01-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HCL001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Hydrogen Peroxide</td>
                                                    <td>7722-84-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>HP001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Nitric Acid</td>
                                                    <td>7697-37-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>NA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Potassium Chloride</td>
                                                    <td>7447-40-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PC001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Potassium Permanganate</td>
                                                    <td>7722-64-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PP001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Yellow Passivation (Hexavalent)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>YPH001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Yellow Passivation (Trivalent)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>YPT001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Zinc Black</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ZB001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Zinc Salt (A)</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ZSA001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td>Zinc Salt Powder</td>
                                                    <td>Not Applicable</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>ZSP001</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Accordion Item 7 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingSeven">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                    PETRO CHEMICALS & SOLVENTS
                                </button>
                            </h2>
                            <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="mb-3">
                                        <input type="text" id="productSearch6" class="form-control"
                                            placeholder="Search for a product...">
                                    </div>
                                    <table class="table table-bodered  table-striped" id="productTable6">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>CAS No</th>
                                                <th>MSDS</th>
                                                <th>Code</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Acetic Acid</td>
                                                <td>64-19-7</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>AA001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Acetone</td>
                                                <td>67-64-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>AC001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Benzene</td>
                                                <td>71-43-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>BE001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Butyl Acetate</td>
                                                <td>123-86-4</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>BA001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Butyl Acrylate Monomer</td>
                                                <td>141-32-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>BAM001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Butyl Glycol</td>
                                                <td>111-76-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>BG001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>C-9</td>
                                                <td>Not Applicable</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>C9001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Chloroform</td>
                                                <td>67-66-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>CH001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Cyclo Hexanone</td>
                                                <td>108-94-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>CH001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Di Methyl Formamide</td>
                                                <td>68-12-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>DMF001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Enamel Thinner</td>
                                                <td>Not Applicable</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>ET001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Epoxy Thinner</td>
                                                <td>Not Applicable</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>ET001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Ethylene Dichloride (EDC)</td>
                                                <td>107-06-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>EDC001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Hexane</td>
                                                <td>110-54-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>HX001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Iso Butanol</td>
                                                <td>78-83-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>IB001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Isopropyl Alcohol (IPA)</td>
                                                <td>67-63-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>IPA001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Methyl Ethyl Ketone (MEK)</td>
                                                <td>78-93-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>MEK001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Methylene Dichloride (MDC)</td>
                                                <td>75-09-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>MDC001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Mineral Turpentine Oil (MTO)</td>
                                                <td>8052-41-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>MTO001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Mix Xylene</td>
                                                <td>1330-20-7</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>MX001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Mono Ethylene Glycol (MEG)</td>
                                                <td>107-21-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>MEG001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>N-Butanol</td>
                                                <td>71-36-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>NB001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>NC Thinner</td>
                                                <td>Not Applicable</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>NCT001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Phenol</td>
                                                <td>108-95-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PHE001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Propylene Glycol (PG)</td>
                                                <td>57-55-6</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PG001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>PU Thinner</td>
                                                <td>Not Applicable</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PUT001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Styrene Monomer</td>
                                                <td>100-42-5</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>SM001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>

                                            <tr>
                                                <td>Tetra Chloro Ethylene (OR)<br>Perchloro Ethylene (Perc Oil)</td>
                                                <td>127-18-4</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>TCE001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Toluene</td>
                                                <td>108-88-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>TO001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Trichloro Ethylene (TCE)</td>
                                                <td>79-01-6</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>TCE002</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Vinyl Acetate Monomer</td>
                                                <td>108-05-4</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>VAM001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>White Spirit</td>
                                                <td>8052-41-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>WS001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td>Xylene</td>
                                                <td>1330-20-7</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>XY001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>



                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Accordion Item 2 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    POULTRY CHEMICALS
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="mb-3">
                                        <input type="text" id="productSearch7" class="form-control"
                                            placeholder="Search for a product...">
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-bodered  table-striped" id="productTable7">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>CAS No</th>
                                                    <th>MSDS</th>
                                                    <th>Code</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><a href="#">Acetic Acid</a></td>
                                                    <td>67-60-4</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00044</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Bleaching Powder</a></td>
                                                    <td>67-60-5</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00045</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Copper Sulphate</a></td>
                                                    <td>67-60-6</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00046</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Formalin (Formaldehyde)</a></td>
                                                    <td>67-60-7</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00047</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Hydrochloric Acid</a></td>
                                                    <td>67-60-8</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00048</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Hydrogen Peroxide (H₂O₂)</a></td>
                                                    <td>67-60-9</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00049</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Chloride</a></td>
                                                    <td>67-61-0</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00050</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Potassium Permanganate (KMnO₄)</a></td>
                                                    <td>67-61-1</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00051</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Sodium Hypochlorite</a></td>
                                                    <td>67-61-2</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00052</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                                <tr>
                                                    <td><a href="#">Zinc Oxide</a></td>
                                                    <td>67-61-3</td>
                                                    <td><button class="btn btn-secondary btn-sm">Request MSDS</button>
                                                    </td>
                                                    <td>PPCGC00053</td>
                                                    <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingEight">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                    WATER TREATMENT CHEMICALS
                                </button>
                            </h2>
                            <div id="collapseEight" class="accordion-collapse collapse" aria-labelledby="headingEight"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="mb-3">
                                        <input type="text" id="productSearch8" class="form-control"
                                            placeholder="Search for a product...">
                                    </div>

                                    <!-- First Table -->
                                    <span class="water-h3 ">General </span>
                                    <table class="table table-bodered  table-striped" id="productTable8">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>CAS No</th>
                                                <th>MSDS</th>
                                                <th>Code</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><a href="#">ALUM (FERRIC)</a></td>
                                                <td>10043-01-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00001</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">ALUM (NON-FERRIC)</a></td>
                                                <td>1327-41-9</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00002</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">BIOCULTURE</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00003</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">BLEACHING POWDER</a></td>
                                                <td>7778-54-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00004</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">CALCIUM HYPOCHLORITE</a></td>
                                                <td>7778-54-3</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00005</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">CAUSTIC SODA</a></td>
                                                <td>1310-73-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00006</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">CITRIC ACID</a></td>
                                                <td>77-92-9</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00007</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">DECOLORANT</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00008</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">ETHYLENE DIAMINE TETRA ACETIC ACID (EDTA)</a></td>
                                                <td>60-00-4</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00009</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">FERRIC CHLORIDE</a></td>
                                                <td>7705-08-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00010</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">HYDRATED LIME POWDER</a></td>
                                                <td>1305-62-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00011</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">HYDRAZINE HYDRATE-80%</a></td>
                                                <td>7803-57-8</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00012</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">HYDROCHLORIC ACID-32%</a></td>
                                                <td>7647-01-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00013</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">HYDROGEN PEROXIDE-50%</a></td>
                                                <td>7722-84-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00014</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>


                                            <!-- Existing products -->
                                            <tr>
                                                <td><a href="#">LIQUID AMMONIA</a></td>
                                                <td>7664-41-7</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00015</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">MICROBES AND ENZYMES</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00016</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">NITRIC ACID-55%, 60%, 72%</a></td>
                                                <td>7697-37-2</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00017</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">OXYGEN SCAVENGERS</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00018</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <!-- New products -->
                                            <tr>
                                                <td><a href="#">POLY ALUMINIUM CHLORIDE (L/P)</a></td>
                                                <td>1327-41-9</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00019</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">POLY ELECTROLYTE ANIONIC</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00020</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">POLY ELECTROLYTE CATIONIC</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00021</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">SODA ASH</a></td>
                                                <td>497-19-8</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00022</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">SODIUM CHLORIDE</a></td>
                                                <td>7647-14-5</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00023</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">SODIUM HYPO CHLORITE</a></td>
                                                <td>7681-52-9</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00024</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">SODIUM META BI SULPHATE</a></td>
                                                <td>7681-57-4</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00025</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">SODIUM SULPHATE</a></td>
                                                <td>7757-82-6</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00026</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>


                                        </tbody>
                                    </table>

                                    <!-- Second Table -->
                                    <span class="water-h3">Ro Plant </span>
                                    <table class="table table-bodered  table-striped" id="productTable8">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>CAS No</th>
                                                <th>MSDS</th>
                                                <th>Code</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><a href="#">RO ANTISCALANT</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00027</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">PH BOOSTER</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00028</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">SODIUM BICARBONATE</a></td>
                                                <td>144-55-8</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00029</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">SCALE REMOVER (HCL)</a></td>
                                                <td>7647-01-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00030</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>

                                        </tbody>
                                    </table>

                                    <!-- Third Table -->
                                    <span class="water-h3">Swimming Pool</span>
                                    <table class="table table-bodered  table-striped" id="productTable8">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>CAS No</th>
                                                <th>MSDS</th>
                                                <th>Code</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="productTable">
                                            <tr>
                                                <td><a href="#">TCCA 90</a></td>
                                                <td>87-90-1</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00031</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">COPPER SULPHATE</a></td>
                                                <td>7758-99-8</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00032</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">CHLORINE</a></td>
                                                <td>7782-50-5</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00033</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">HYDROCHLORIC ACID</a></td>
                                                <td>7647-01-0</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00034</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">HYPOCHLORITE</a></td>
                                                <td>7681-52-9</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00035</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>
                                            <tr>
                                                <td><a href="#">GENERAL HOUSEKEEPING CHEMICAL</a></td>
                                                <td>N/A</td>
                                                <td><button class="btn btn-secondary btn-sm">Request MSDS</button></td>
                                                <td>PPCGC00036</td>
                                                <td><button class="btn btn-primary btn-sm">Get A Quote</button></td>
                                            </tr>

                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
  
    <!--=====TEAM AREA END=======-->


    <!--=====OUR VALUES AREA START=======-->

    <div class="our-values sp bg1">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="heading1 pl-50 md:pl-0 xs:pl-0 md:pt-30 sm:pt-30">
                        <span class="span1 text-18 leading-18 title1 font-normal mb-16"> Our Values</span>
                        <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold title1">We work is conducted
                            honest transparency.</h2>
                        <div class="our-values-box">
                            <div class="icon">
                                <span><i class="fa-solid fa-check"></i></span>
                            </div>
                            <div class="heading1">
                                <h4><a href="#" class="text-18 leading-18 font-semibold title1">Excellence</a></h4>
                                <p class="mt-10 text-16 font-normal pera1 mt-14 leading-26">We are committed to
                                    achieving the highest levels of quality in everything we do.</p>
                            </div>
                        </div>

                        <div class="our-values-box">
                            <div class="icon">
                                <span><i class="fa-solid fa-check"></i></span>
                            </div>
                            <div class="heading1">
                                <h4><a href="#" class="text-18 leading-18 font-semibold title1">Innovation</a></h4>
                                <p class="mt-10 text-16 font-normal pera1 mt-14 leading-26">We foster a culture of
                                    creativity and continuous improvement, embracing new ideas and technologies.</p>
                            </div>
                        </div>

                        <div class="our-values-box">
                            <div class="icon">
                                <span><i class="fa-solid fa-check"></i></span>
                            </div>
                            <div class="heading1">
                                <h4><a href="#" class="text-18 leading-18 font-semibold title1">Collaboration</a></h4>
                                <p class="mt-10 text-16 font-normal pera1 mt-14 leading-26">We believe that the best
                                    results come from working together, both within our teams and with our clients and
                                    partners.</p>
                            </div>
                        </div>

                        <div class="button mt-30">
                            <a href="{{route('about')}}"
                                class="theme-btn15 inline-block white text-16 leading-16 font-semibold ">About Us
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="image image-anime _relative">
                                <img class="w-full" src="{{asset('/img/about/values-img1.png')}}" alt="">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="image sm:mt-20 image-anime _relative">
                                <img class="w-full" src="{{asset('/img/about/values-img2.png')}}" alt="">
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="image mt-30 image-anime _relative">
                                <img class="w-full" src="{{asset('/img/about/values-img3.png')}}" alt="">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div> 

    <!--=====OUR VALUES AREA END=======-->


@endsection

@push('styles')

    <style>
        /* font famaily properties */
        :root {
            --font1: Poppins;
        }
     
       

        h1,
        h2,
        h3,
        a,
        span {
            font-family: var(--font1);
        }

        a {
            font-size: 18px !important;
        }



        /* font color changing */
        .font-color-footer {
            color: rgb(91, 185, 223);

        }




        .ulr li:nth-child(odd) {
            background: linear-gradient(45deg, #87cefa, #f0f8ff);
            color: #333;
            transition: background 1s ease, color 0.5s ease;
            margin: 5px;
            padding: 15px;
            border-radius: 5px;
            min-width:200px;
        }

        .ulr li:nth-child(even) {
            background: linear-gradient(45deg, #f0f8ff, #87cefa);
            color: #333;
            transition: background 1s ease, color 0.5s ease;
            margin: 5px;
            border-radius: 5px;
            padding: 15px;
            min-width:200px;
        }

        .ulr li:hover {
            background: linear-gradient(45deg, #4682b4, #1e90ff);
            color: #fff;
        }

        .water-h3 {
            font-weight: bold;
            font-size: 20px;
            color: blue;
            position: relative;
            animation: slideUp 2s ease-out forwards;
            box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
            display: grid;
            justify-content: center;
            margin: 20px 0px;

        }

        /* @keyframes slideUp {
            from {
                transform: translateY(100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        } */
    </style>
   
@endpush




@push('scripts')
<script>
window.onload = function () {
    // Get the URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const openAccordion = urlParams.get('open'); // Get the "open" parameter
    console.log('URL Parameter:', openAccordion); // Debug

    // Map 'open' parameter values to accordion IDs
    const accordionMap = {
        acid: '#collapseOne',
        poultry: '#collapseTwo',
        food: '#collapseThree',
        hygiene: '#collapseFour',
        hygiene1: '#collapseFive',
        metal: '#collapseSix',
        petrol: '#collapseSeven',
        water: '#collapseEight',
    };

    // Check if the 'open' parameter matches a key in the map
    if (openAccordion && accordionMap[openAccordion]) {
        const targetAccordion = document.querySelector(accordionMap[openAccordion]);
        console.log('Target Accordion:', targetAccordion); // Debug

        if (targetAccordion) {
            // Get the corresponding accordion button
            const accordionButton = targetAccordion.previousElementSibling.querySelector('.accordion-button');

            // Use Bootstrap Collapse to expand the target accordion
            const bootstrapAccordion = new bootstrap.Collapse(targetAccordion, { toggle: true });
            console.log('Accordion Expanded:', bootstrapAccordion); // Debug

            // Add a slight delay to ensure the accordion expands before scrolling
            setTimeout(() => {
                // Scroll to the accordion
                targetAccordion.scrollIntoView({ behavior: 'smooth', block: 'center' });

                // Focus the accordion button for accessibility
                if (accordionButton) {
                    accordionButton.focus();
                }
            }, 500);
        }
    }
};


    </script>

    <script>
        function filterTable(inputId, tableId) {
            const filter = document.getElementById(inputId).value.toLowerCase();
            const rows = document.querySelectorAll(`#${tableId} tbody tr`);

            rows.forEach(row => {
                const productName = row.cells[0].textContent.toLowerCase();
                if (productName.includes(filter)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }

        // Event Listeners for both tables
        document.getElementById("productSearch1").addEventListener("input", function () {
            filterTable("productSearch1", "productTable1");
        });

        document.getElementById("productSearch2").addEventListener("input", function () {
            filterTable("productSearch2", "productTable2");
        });
        document.getElementById("productSearch3").addEventListener("input", function () {
            filterTable("productSearch3", "productTable3");
        });
        document.getElementById("productSearch4").addEventListener("input", function () {
            filterTable("productSearch4", "productTable4");
        });
        document.getElementById("productSearch5").addEventListener("input", function () {
            filterTable("productSearch5", "productTable5");
        });
        document.getElementById("productSearch6").addEventListener("input", function () {
            filterTable("productSearch6", "productTable6");
        });
        document.getElementById("productSearch7").addEventListener("input", function () {
            filterTable("productSearch7", "productTable7");
        });
        document.getElementById("productSearch8").addEventListener("input", function () {
            filterTable("productSearch8", "productTable8");
        });

    </script>
@endpush