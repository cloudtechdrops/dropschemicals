<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">

  

    <title>@yield('title', 'DropsChemicals')</title>

    <!-- Styles -->
    <link rel="shortcut icon" href="{{asset('/img/New%20folder/icon/slide-icon.ico')}}" type="image/x-icon">
  

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!--=====CSS=======-->
  <link rel="stylesheet" href="{{asset('/css/bootstrap.min.css')}}">
  <link rel="stylesheet" href="{{asset('/css/fontawesome.css')}}">
  <link rel="stylesheet" href="{{asset('/css/magnific-popup.css')}}">
  <link rel="stylesheet" href="{{asset('/css/nice-select.css')}}">
  <link rel="stylesheet" href="{{asset('/css/slick-slider.css')}}">
  <link rel="stylesheet" href="{{asset('/css/owl.carousel.min.css')}}">
  <link rel="stylesheet" href="{{asset('/css/aos.css')}}">
  <link rel="stylesheet" href="{{asset('/css/bundle.min.css')}}">
  <link rel="stylesheet" href="{{asset('/css/mobile-menu.css')}}">
  <link rel="stylesheet" href="{{asset('/css/utility.css')}}">
  <link rel="stylesheet" href="{{asset('/css/main.css')}}">
  <link rel="stylesheet" href="{{asset('/css/image.css')}}">
  <link rel="stylesheet" href="{{asset('/css/color.css')}}
  ">
  
  <style>
    body{
      box-sizing: border-box !important;
      margin: 0 !important;
      padding: 0 !important;
      overflow-x: hidden !important;
    
}


    /* font color changing */
   :root {
  --font1: Poppins;
}
h1,h2,h3,span,a{
  font-family: var(--font1);
}
a{
  font-size: 18px !important;
}

/* font properties end */

/* font color changing */
.font-color-footer{
  color:rgb(91, 185, 223);

}

 .animated-image {
      animation: zoomIn 1s ease-in-out;
    }

    @keyframes zoomIn {
      0% {
        transform: scale(0.8);
        opacity: 0;
      }

      100% {
        transform: scale(0.8);
        opacity: 1;
      }
    }

    /* image color */
    .image-clr {
      background-image: linear-gradient(90deg, transparent, rgb(47, 141, 218));
    }




    /* menu */


    /* .menuR {

      background-color: rgb(231, 237, 243);
      border-radius: 5%;

    } */

    .menuR>a>i {
      /* color: #0000FF; */
      padding-right: 2px;
padding: 2px 2px;
    }






    /* rotation animation  header image */

    @keyframes rotate {
      10% {
        transform: rotate(0deg);
      }

      45% {
        transform: rotate(4deg);
      }

      65% {
        transform: rotate(4deg);
      }

      0% {
        transform: rotate(0deg);
      }
    }

    /* Apply animation to the image */
    #resize-img {

      animation: rotate 10s linear infinite;
      background-size: cover;width:100%;height: 100%;
     
    }

    #resize-img:hover {
      animation-play-state: paused !important;
    }



    /* mobile device */
    @media (max-width: 765px) {
      #resize-1{
      max-width: 155px;
      max-height: 155px;

    }

    .resize-1{
      position: absolute; top: 5%; left: 18%;
    }
.resize-2{
  position: absolute;left:0; bottom: 25%; 

}
.resize-3{
  position: absolute;right: 0;bottom: 25%;
}

     
    }

    /* tab devices */

    @media screen and (min-width: 765px) and (max-width: 980px) {
      #resize-1{
      max-width: 240px;
      max-height: 240px;
    }
    .resize-1{
      position: absolute; top: 5%; left: 18%;
    }
.resize-2{
  position: absolute;left:0; bottom: 25%; 

}
.resize-3{
  position: absolute;right: 0;bottom: 25%;
}
     
    }

    /* laptop devices */

    @media (min-width: 981px) {
      #resize-1{
      max-width: 200px;
      max-height: 200px;
    }

    }
    #resize-1{
      padding: 0;
      border-radius: 50%;
    }


    .resize-1{
      position: absolute; top: 5%; left: 18%;
    }
.resize-2{
  position: absolute;left:0; bottom: 25%; 

}
.resize-3{
  position: absolute;right: 0;bottom: 25%;
}



@media screen and (min-width: 992px) and (max-width: 1200px) {
  .rsize>ul>li>a {
    /* Change width to 90% between 992px and 1200px */
    font-size: 15px !important; /* Increase font size */
    padding:0;
    
  }
  .rsize>ul>li{
    padding:5px 2px;
  }
}

    
  </style>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    @stack('styles')

    <script src="{{asset('/js/jquery-3-7-1.min.js')}}"></script>
</head>
<body class="body2">
<div class="paginacontainer">

<div class="progress-wrap">
  <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
    <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
  </svg>
</div>


 <!--=====PRELOADER START=======-->

 <div class="preloader-sec">
    <u><i>
      </i></u>
    <div class="app-loader">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
        <g>
          <path d="m 16.999389,6 a 3,3 0 1 1 3,-3 3.00082,3.00082 0 0 1 -3,3 z" id="path3859" />
          <path d="m 23.999389,8 a 2,2 0 1 1 2,-2 1.99884,1.99884 0 0 1 -2,2 z" id="path3857" />
          <path d="m 7.9993894,6.4 a 2,2 0 1 1 2,-2 1.99883,1.99883 0 0 1 -2,2 z" id="path3855" />
          <path
            d="M 2.9720294,30.25 11.026749,15.74608 a 3.303,3.303 0 0 1 0.9726,-1.0078 V 11.5 A 1.89446,1.89446 0 0 1 9.9993494,9.75 1.8918,1.8918 0 0 1 11.999349,8 h 8 a 1.89184,1.89184 0 0 1 2,1.75 1.89449,1.89449 0 0 1 -2,1.75 v 3.23828 a 3.28838,3.28838 0 0 1 0.97168,1.0078 L 29.027709,30.25 A 1.07993,1.07993 0 0 1 27.999389,32 H 3.9993894 a 1.07943,1.07943 0 0 1 -1.02736,-1.75 z"
            id="path3853" />
          <path d="m 24.888029,28 -2.22168,-4 H 9.3313494 l -2.22064,4 z" id="path3728" />
        </g>
      </svg>
    </div>
  </div>

  <!--=====PRELOADER END=======-->


   <!--=====HEADER START=======-->
   <header>
    <div class="header-area header-area1 header-area-all d-none d-lg-block" id="header">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="header-elements">
              <div class="site-logo">
                <a href="{{route('/')}}">
                  <img src="{{asset('/img/logo/Logo-02.png')}}" alt="">
                </a>
              </div>


              <div class="main-menu-ex main-menu-ex1 rsize">
                <ul>
                  <li class="menuR"><a href="{{route('/')}}"><i class="fa-solid fa-house "></i> Home</a></li>


                  <li class="dropdown-menu-parrent menuR"> <a href="{{route('ourservices')}}"><i
                        class="fa-solid fa-clipboard-list"></i>Our Services <i class="fa-solid fa-angle-down "></i></a>
                    <ul>

                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'acid']) }}">Agro & Aquaculture<span><i
                              class="fa-solid"></i></span></a>

                      </li>
                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'hygiene']) }}">Detergent and Soap<span><i
                              class="fa-solid"></i></span></a>
                      </li>

                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'food']) }}">Food<span><i class="fa-solid"></i></span></a>
                      </li>
                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'hygiene1']) }}">Hygiene<span><i class="fa-solid"></i></span></a>
                      </li>

                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'metal']) }}">Metal Finishing<span><i class="fa-solid"></i></span></a>
                      </li>
                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'petrol']) }}">Petro<span><i class="fa-solid"></i></span></a>
                      </li>
                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'poultry']) }}">Poultry<span><i class="fa-solid"></i></span></a>
                      </li>
                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'solvents']) }}">Solvents<span><i class="fa-solid"></i></span></a>
                      </li>
                      <li class="has-dropdown has-dropdown1">
                      <a href="{{ route('ourservices', ['open' => 'water']) }}">Water Treatment<span><i class="fa-solid"></i></span></a>
                      </li>


                    </ul>
                  </li>


                  <li class="dropdown-menu-parrent menuR"><a href="{{route('career')}}" class="main1"><i
                        class="fa-solid fa-user-tie "></i>Career </a>
                  </li>

                  <li class="dropdown-menu-parrent menuR"><a href="{{route('blog')}}" class="main1"> <i
                        class="fa-solid fa-blog"></i>Blog </a>
                  </li>



                  <li class="menuR"><a href="{{ route('contact', ['id' => 'feed']) }}"><i class="fa-solid fa-comments"></i>Feedback</a></li>
                  <li class="menuR"><a href="{{route('about')}}"><i class="fa-solid fa-circle-info"></i>About</a></li>

                </ul>
              </div>


              <div class="header1-buttons ">
                <a class="theme-btn1 theme-btnn" href="{{route('contact')}}">Contact Us <span class="arrow1"><i
                      class="fa-solid fa-arrow-right"></i></span><span class="arrow2"><i
                      class="fa-solid fa-arrow-right"></i></span></a>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!--=====HEADER END=======-->

  <!--=====Mobile header start=======-->
  <div class="mobile-header mobile-header-main d-block d-lg-none ">
    <div class="container-fluid">
      <div class="col-12">
        <div class="mobile-header-elements">
          <div class="mobile-logo">
            <a href="{{route('/')}}"><img src="{{asset('/img/logo/Logo-02.png')}}"  alt=""></a>
          </div>
          <div class="mobile-nav-icon">
            <i class="fa-duotone fa-bars-staggered"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="mobile-sidebar d-block d-lg-none">
    <div class="logo-m">
      <a href="{{route('/')}}"><img src="{{asset('/img/logo/Logo-02.jpg')}}"  style="width:200px;height:60px" alt=""></a>
    </div>
    <div class="menu-close">
      <i class="fa-solid fa-xmark"></i>
    </div>
    <div class="mobile-nav">

      <ul>
        <li class="has-dropdown"><a href="{{route('/')}}">Home </a>
        </li>
        <li class="has-dropdown"><a href="{{route('ourservices')}}">Our Services</a>
          <ul class="sub-menu">
          <li><a href="{{ route('ourservices', ['open' => 'acid']) }}">Agro & Aquaculture</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'hygiene']) }}">Detergent and Soap</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'food']) }}">Food</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'hygiene1']) }}">Hygiene</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'metal']) }}">Metal Finishing</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'petrol']) }}">Petro</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'poultry']) }}">Poultry</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'solvents']) }}">Solvents</a></li>
        <li><a href="{{ route('ourservices', ['open' => 'water']) }}">Water Treatment</a></li>
          </ul>
        </li>
        <li><a href="{{route('about')}}">About Us</a></li>
        <li><a href="{{route('career')}}">Career</a></li>
        <li><a href="{{ route('contact', ['id' => 'feed']) }}">Feedback</a></li>
        <li><a href="{{route('blog')}}">Blog</a></li>
       
      </ul>

      <div class="mobile-button">
        <a class="theme-btn3" href="{{route('contact')}}">Get A Quote <i class="fa-solid fa-arrow-right"></i></a>
      </div>

      <div class="footer-contact-area1 md:pl-0 pl-20 sm:pl-0 mt-30">
        <h3 class="text-24 leading-26 font-semibold title1 pb-10">Get in touch</h3>
        <div class="contact-box d-flex">
          <div class="icon">
            <img src="{{asset('/img/icons/footer1-icon1.svg')}}" alt="">
          </div>
          <div class="text">
            <a href="mailto:Infodtopschemical@gmail.com">Infodropschemical@gmail.com</a>
          </div>
        </div>

        <div class="contact-box d-flex">
          <div class="icon">
            <img src="{{asset('/img/icons/footer1-icon2.svg')}}" alt="">
          </div>
          <div class="text">
            <a href="https://www.google.com/maps?q=7/8-5+Athikadavu+Road,+Keeranatham,+Tamil+Nadu+641035"
              target="_blank">
              7/8-5, Athikadavu Road,<br> Keeranatham, Tamil Nadu 641035, India
            </a>
          </div>
        </div>

        <div class="contact-box d-flex">
          <div class="icon">
            <img src="{{asset('/img/icons/footer1-icon3.svg')}}" alt="">
          </div>
          <div class="text">
            <a href="tel:+91 90426 70008">91 90426 70008</a>
          </div>
        </div>

      </div>

      <div class="contact-infos">
        <h3>Our Location</h3>
        <ul class="social-icon">
          <li><a href="https://www.linkedin.com/company/dropschemical/"><i class="fa-brands fa-linkedin-in"></i></a>
          </li>
          <li><a href="https://www.youtube.com/@DropsChemicals-um5cm"><i class="fa-brands fa-youtube"></i></a></li>
          <li><a href="https://www.facebook.com/dropschemical/"><i class="fa-brands fa-facebook-f"></i></a></li>
          <li><a href="https://www.instagram.com/drops.chemicals?igsh=MTg3enIxcTR4dmw1dw=="><i
                class="fa-brands fa-instagram"></i></a></li>
        </ul>
      </div>

    </div>
  </div>



  <!--=====Mobile header end=======-->

</div>

    <main>
        
            @yield('content')
        
    </main>

    <footer>
    <div class="cta1 sp" style="background:linear-gradient(109.6deg, rgb(163, 217, 207) 11.2%, rgb(4, 178, 217) 100.2%)">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-5">
          <h2 class="text-44 sm:text-30 md:text-30 leading-56 font-semibold white">Ready to Innovate in Chemical &
            Metrical?</h2>
        </div>
        <div class="col-lg-7">
          <div class="buttons text-end md:text-start xs:text-start sm:mt-20 md:mt-20">
            <a href="{{route('contact')}}" class="theme-btn16 inline-block white text-16 leading-16 font-semibold "><i class="fa-solid fa-phone" style="padding-right:3px;"></i>Contact Us
              Now</a>
            <a href="{{route('ourservices')}}"
              class="theme-btn15 ml-20 sm:ml-0 inline-block white text-16 leading-16 font-semibold "> <i
              class="fa-solid fa-clipboard-list"></i>Our Service
              Now </a>
          </div>
        </div>
      </div>
    </div>
  </div>


         <!--=====FOOTER AREA START=======-->

  <div class="footer1 mt-80">
    <div class="container">
      <div class="row">

        <div class="col-lg-3">
          <div class="logo-area">
            <a href="{{route('/')}}">
              <img src="{{asset('/img/logo/Logo-02.png')}}" alt="">
            </a>
            <p class="mt-16 text-16 font-normal pera1 leading-">With our focus on customer satisfaction and our
              extensive
              experience in this industry, we are confident that we can meet
              your chemical supply needs.</p>
            <ul class="footer-social-area1 mt-20">
              <li><a href="https://www.facebook.com/dropschemical/"><i class="fa-brands fa-facebook-f"></i></a></li>
              <li><a href="https://www.instagram.com/drops.chemicals?igsh=MTg3enIxcTR4dmw1dw=="><i
                    class="fa-brands fa-instagram"></i></a></li>
              <li><a href="https://www.linkedin.com/company/dropschemical/"><i class="fa-brands fa-linkedin-in"></i></a>
              </li>
              <li><a href="https://www.youtube.com/@DropsChemicals-um5cm"><i class="fa-brands fa-youtube"></i> </a></li>
            </ul>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <div class="pl-20 sm:pl-0 md:pl-0 sm:mt-30 md:mt-30">
            <h3 class="text-24 leading-26 font-semibold title1 pb-20 font-color-footer " >About Link</h3>
            <ul class="footer-list1">
              <li><a href="{{route('/')}}">Home</a></li>
              <li><a href="{{route('about')}}">About Us</a></li>
              <li><a href="{{route('ourservices')}}">Our Services</a></li>
              <li><a href="{{route('blog')}}">Blog</a></li>
              <li><a href="{{route('contact')}}">Contact Us</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="footer-contact-area1 md:pl-0 pl-20 sm:pl-0 sm:mt-30 md:mt-30">
            <h3 class="text-24 leading-26 font-semibold title1 pb-10 font-color-footer">Get in touch</h3>

            <div class="contact-box d-flex">
              <div class="icon">
                <img src="{{asset('/img/icons/footer1-icon1.svg')}}" alt="">
              </div>
              <div class="text">
                <a href="mailto:info@dropschemicals.com">info@dropschemicals</a>
              </div>
            </div>


            <div class="contact-box d-flex">
              <div class="icon">
                <img src="{{asset('/img/icons/footer1-icon2.svg')}}" alt="">
              </div>
              <div class="text">
                <a href="https://www.google.com/maps?q=7/8-5+Athikadavu+Road,+Keeranatham,+Tamil+Nadu+641035"
                  target="_blank">
                  7/8-5, Athikadavu Road,<br> Keeranatham, Tamil Nadu 641035, India
                </a>
              </div>
            </div>

            <div class="contact-box d-flex">
              <div class="icon">
                <img src="{{asset('/img/icons/footer1-icon3.svg')}}" alt="">
              </div>
              <div class="text">
                <a href="tel:+919677522201">96775 22201</a>
              </div>
            </div>

          </div>
        </div>
        <div class="col-lg-4">
          <div class="footer1-form-area sm:mt-30 md:mt-30">
            <h3 class="text-24 leading-26 font-semibold title1 pb-20 font-color-footer">Subscribe</h3>
            <form id="subscribe-form" class="_relative mt-10">
    @csrf <!-- CSRF Token -->
    <input type="email" id="subscribe-email" name="email" placeholder="Enter Your Email" required>
    <div class="button absolute top-0 right-0">
        <button class="theme-btn3" type="button" id="subscribe-button">
            Subscribe
            <span class="arrow1"><i class="fa-solid fa-arrow-right"></i></span>
            <span class="arrow2"><i class="fa-solid fa-arrow-right"></i></span>
        </button>
    </div>
</form>
            <div id="message" style="margin-top: 10px;"></div>

          </div>
        </div>
      </div>

      <div class="row align-items-center coppy-right1">
        <div class="col-lg-6">
          <p class="text-16 font-normal pera1 leading-26">&#169;Copyright {{ date('Y') }} Drops Chemicals . All rights reserved</p>
        </div>
        <div class="col-lg-6">
          <div class="conditons-area1">
            <a href="#" class="text-16 font-normal pera1 leading-26">Terms & Conditions</a>
            <a href="#" class="text-16 font-normal pera1 leading-26 after-add"> Privacy Policy</a>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!--=====FOOTER AREA END=======-->
       

   
    @stack('scripts')

    <script src="{{asset('/js/bootstrap.min.js')}}"></script>
  <script src="{{asset('/js/fontawesome.js')}}"></script>
  <script src="{{asset('/js/mobile-menu.js')}}"></script>
  <script src="{{asset('/js/jquery.magnific-popup.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

  <script src="{{asset('/js/jquery.countup.js')}}"></script>
  <script src="{{asset('/js/slick-slider.js')}}"></script>
  <script src="{{asset('/js/circle-progress.js')}}"></script>
  <script src="{{asset('/js/jquery.nice-select.js')}}"></script>
 

  <script src="{{asset('/js/swiper-bundle.js')}}"></script>
  <script src="{{asset('/js/Splitetext.js')}}"></script>
  <!-- <script src="assets/js/text-animation.js"></script> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
  
  <script src="{{asset('/js/aos.js')}}"></script>
  <script src="{{asset('/js/SmoothScroll.js')}}"></script>
  <script src="{{asset('/js/jaquery-ripples.js')}}"></script>
  <script src="{{asset('/js/jquery.lineProgressbar.js')}}"></script>
  <!-- <script src="{{asset('/js/animation.js')}}"></script> -->
  <script src="{{asset('/js/main.js')}}"></script>
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script> -->

  
 <script>
document.getElementById('subscribe-button').addEventListener('click', function (event) {
    event.preventDefault();

    const email = document.getElementById('subscribe-email').value;
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

    if (!email) {
        alert("Please enter a valid email address.");
        return;
    }

    fetch('{{ route("subscribe") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken,
        },
        body: JSON.stringify({ email: email }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            document.getElementById('subscribe-email').value = ''; // Clear the input field
        } else {
            alert(data.message);
            console.error(data.error);
        }
    })
    .catch(error => {
        alert('An error occurred. Please try again.');
        console.error(error);
    });
});


</script>



  @stack('scripts')

  
</body>
</html>
