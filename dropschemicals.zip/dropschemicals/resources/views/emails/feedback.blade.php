<h3>Feedback from {{ $feedbackData['companyName'] }}</h3>
<p><strong>Date:</strong> {{ $feedbackData['date'] }}</p>
<p><strong>Survey Completed by:</strong> {{ $feedbackData['surveyBy'] }}</p>
<p><strong>Phone:</strong> {{ $feedbackData['phone'] }}</p>
<p><strong>Email:</strong> {{ $feedbackData['email'] }}</p>

<h4>Feedback Responses:</h4>
<p><strong>1. What products, and or services did you purchase?</strong> {{ $feedbackData['products'] }}</p>
<p><strong>2. Was the purchasing experience positive?:</strong> {{ $feedbackData['experience'] }}</p>

<p><strong>3. Supplier Performance:</strong></p>
<p><strong>Price:</strong> {{ $feedbackData['price'] }}</p>
<p><strong>Quality:</strong> {{ $feedbackData['quality'] }}</p>

<p><strong>4. Did the products meet expectations?:</strong> {{ $feedbackData['expectations'] }}</p>
<p><strong>5. Suggestions to improve service:</strong> {{ $feedbackData['suggestions'] }}</p>
