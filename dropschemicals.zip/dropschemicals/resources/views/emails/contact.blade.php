<h3>New Contact Form Submission</h3>
<p><strong>First Name:</strong> {{ $formData['first_name'] }}</p>
<p><strong>Last Name:</strong> {{ $formData['last_name'] }}</p>
<p><strong>Email:</strong> {{ $formData['email'] }}</p>
<p><strong>Phone Number:</strong> {{ $formData['phone_number'] }}</p>
<p><strong>Location:</strong> {{ $formData['location'] }}</p>
<p><strong>Company Name:</strong> {{ $formData['company'] }}</p>
<p><strong>Product:</strong> {{ $formData['product'] }}</p>
<p><strong>Quantity:</strong> {{ $formData['quantity'] }}</p>
<p><strong>Type of Industry:</strong> {{ $formData['industry'] }}</p>
<p><strong>Message:</strong> {{ $formData['message'] }}</p>
