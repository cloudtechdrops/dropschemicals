<p><strong>Full Name:</strong> {{ $full_name }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Position:</strong> {{ $position }}</p>
<p><strong>Employment Status:</strong> {{ $employment_status }}</p>
